<?php
/**
 * The Amazon Web Services Key
 */
$config['aws_key'] = '';

/**
 * The Amazon Secret Key
 */
$config['aws_secret'] = '';
?>
