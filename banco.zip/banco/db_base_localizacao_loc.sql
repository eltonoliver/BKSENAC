CREATE DATABASE  IF NOT EXISTS `db_base` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `db_base`;
-- MySQL dump 10.13  Distrib 5.6.17, for Win32 (x86)
--
-- Host: 127.0.0.1    Database: db_base
-- ------------------------------------------------------
-- Server version	5.6.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `localizacao_loc`
--

DROP TABLE IF EXISTS `localizacao_loc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `localizacao_loc` (
  `loc_codlocalizacao` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `loc_data` date NOT NULL,
  `loc_hora` varchar(10) NOT NULL,
  `loc_codcolaborador` int(10) unsigned NOT NULL,
  `loc_codusuario` int(10) unsigned NOT NULL,
  `loc_codunidade` int(10) unsigned NOT NULL,
  `loc_tipolocalizacao` int(11) NOT NULL,
  `loc_codunidadelocalizacao` int(11) DEFAULT NULL,
  `loc_nomelocalizacao` varchar(150) NOT NULL,
  `loc_observacao` text,
  `loc_situacao` int(11) NOT NULL,
  PRIMARY KEY (`loc_codlocalizacao`),
  KEY `fk_loc_codcolaborador` (`loc_codcolaborador`),
  KEY `fk_loc_codusuario` (`loc_codusuario`),
  KEY `fk_loc_codunidade` (`loc_codunidade`),
  CONSTRAINT `fk_loc_codcolaborador` FOREIGN KEY (`loc_codcolaborador`) REFERENCES `colaborador_col` (`col_codcolaborador`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_loc_codunidade` FOREIGN KEY (`loc_codunidade`) REFERENCES `unidade_uni` (`uni_codunidade`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_loc_codusuario` FOREIGN KEY (`loc_codusuario`) REFERENCES `usuario_usu` (`usu_codusuario`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `localizacao_loc`
--

LOCK TABLES `localizacao_loc` WRITE;
/*!40000 ALTER TABLE `localizacao_loc` DISABLE KEYS */;
INSERT INTO `localizacao_loc` VALUES (1,'2012-04-02','14:09:29',1,2,1,0,1,'SEDE ADMINISTRATIVA - GIC','Disponibilizando Material no Repositório.',1),(2,'2012-03-07','13:44:25',34,37,8,0,8,'SEDE ADMINISTRATIVA - DAD','ESTOU NA REUNIÃO CIPA QUE OCORRE NO SHOW ROOM',1),(3,'2012-03-15','15:00:03',73,76,17,0,17,'CFP - JOSÉ TADROS','',1),(4,'2012-04-11','10:52:54',159,126,26,0,26,'SEDOC','Estou na Biblioteca do CFP - Pequeno Franco',1),(5,'2012-11-21','11:45:16',89,94,1,0,30,'FATESE','Atendendo as solicitaçoes da Senhora  Karla. ',1),(6,'2012-07-25','11:59:34',19,21,2,0,2,'GERÊNCIA DE TURISMO E HOSPITALIDADE','',1),(7,'2012-08-07','17:12:41',128,22,11,0,11,'SEDE ADMINISTRATIVA - DEP','',1),(8,'2012-08-07','17:20:54',149,121,13,0,11,'SEDE ADMINISTRATIVA - DEP','Gabinete Técnico - DEP - localizado temporariamente no CIN.',1),(9,'2013-07-19','15:30:52',182,135,30,0,30,'FATESE','Faculdade de Tecnologia Senac Amazonas\nRua 10 de Julho, 11 - Centro',1),(10,'2012-11-22','08:26:16',217,144,19,0,19,'CFP - MOYSÉS BENARRÓS ISRRAEL','SECRETARIA',1),(11,'2013-08-05','10:05:10',68,71,13,0,24,'EDUCAÇÃO CORPORATIVA','',1),(12,'2013-08-28','16:35:25',125,110,18,0,18,'CFP - MATHEUS PENNA RIBEIRO','',1),(13,'2014-05-13','14:08:19',351,218,7,0,7,'SEDE ADMINISTRATIVA - GRH','',1);
/*!40000 ALTER TABLE `localizacao_loc` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-07-02 17:13:56
