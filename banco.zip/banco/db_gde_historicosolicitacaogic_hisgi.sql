CREATE DATABASE  IF NOT EXISTS `db_gde` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `db_gde`;
-- MySQL dump 10.13  Distrib 5.6.17, for Win32 (x86)
--
-- Host: 127.0.0.1    Database: db_gde
-- ------------------------------------------------------
-- Server version	5.6.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `historicosolicitacaogic_hisgi`
--

DROP TABLE IF EXISTS `historicosolicitacaogic_hisgi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `historicosolicitacaogic_hisgi` (
  `hisgi_codhistorico` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `hisgi_codsolicitacao` int(10) unsigned NOT NULL,
  `hisgi_codtipo` int(10) unsigned NOT NULL,
  `hisgi_codcolaborador` int(11) NOT NULL,
  `hisgi_nomecolaborador` varchar(60) NOT NULL,
  `hisgi_descricao` text NOT NULL,
  `hisgi_arquivo` varchar(50) DEFAULT NULL,
  `hisgi_codsituacao` int(10) unsigned NOT NULL,
  `hisgi_data` date NOT NULL,
  `hisgi_hora` varchar(10) NOT NULL,
  `hisgi_codregistrante` int(10) unsigned NOT NULL,
  `hisgi_codsituacaoregistro` int(10) unsigned NOT NULL,
  PRIMARY KEY (`hisgi_codhistorico`),
  KEY `fk_hisgi_codsolicitacao` (`hisgi_codsolicitacao`),
  KEY `fk_hisgi_codtipo` (`hisgi_codtipo`),
  KEY `fk_hisgi_codsituacaoregistro` (`hisgi_codsituacaoregistro`),
  KEY `fk_hisgi_codregistrante` (`hisgi_codregistrante`),
  KEY `fk_hisgi_codsituacao` (`hisgi_codsituacao`),
  CONSTRAINT `fk_hisgi_codregistrante` FOREIGN KEY (`hisgi_codregistrante`) REFERENCES `registrantegic_regi` (`regi_codregistrante`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_hisgi_codsituacao` FOREIGN KEY (`hisgi_codsituacao`) REFERENCES `situacaosolicitacaogic_sigic` (`sigic_codsituacao`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_hisgi_codsituacaoregistro` FOREIGN KEY (`hisgi_codsituacaoregistro`) REFERENCES `situacaoregistrogic_siregi` (`siregi_codsituacao`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_hisgi_codsolicitacao` FOREIGN KEY (`hisgi_codsolicitacao`) REFERENCES `solicitacaogic_gic` (`gic_codsolicitacao`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_hisgi_codtipo` FOREIGN KEY (`hisgi_codtipo`) REFERENCES `tipohistoricogic_tipgi` (`tipgi_codtipo`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `historicosolicitacaogic_hisgi`
--

LOCK TABLES `historicosolicitacaogic_hisgi` WRITE;
/*!40000 ALTER TABLE `historicosolicitacaogic_hisgi` DISABLE KEYS */;
INSERT INTO `historicosolicitacaogic_hisgi` VALUES (1,4,1,174,'FERNANDO MAURICIO','Estou criando a conta agora.','',10,'2012-07-18','14:23:22',2,2),(2,4,1,77,'FRANCISCO GAMA','Fernando, fico no aguardo da concousão do serviço.','',10,'2012-07-18','14:29:10',2,2),(3,5,1,174,'FERNANDO MAURICIO','Anexo, o site da Fecomércio com os valores','Certisign - Certificado Digital.pdf',10,'2012-07-19','11:56:19',2,2),(4,5,1,77,'FRANCISCO GAMA','Fernando, agora entre em contato com a prefeitura e procure saber sobre os modelos de certificado, o que é mais viável para o SENAC.\r\n','',10,'2012-07-19','12:02:57',2,2),(5,5,1,77,'FRANCISCO GAMA','Todo processo de certificação, por orientação da DAD deverá ser feito pela FECOMÉRCIO.','',10,'2012-07-19','12:50:19',2,1),(6,5,1,174,'FERNANDO MAURICIO','A resposta quanto as questionamentos foi encaminhada ao MS. Esperamos agora, um parecer e uma data para implementação das notas fiscais em lote.','',5,'2012-07-25','10:08:42',1,2),(7,5,1,174,'FERNANDO MAURICIO','Informo que oo ticket aberto junto ao MS ainda encontra-se EM PAUSA. Atualizado por Thiago Tosta há aproximadamente 1 mês Situação alterado de Em andamento para Em pausa','',8,'2012-08-30','18:03:51',1,2),(8,5,1,174,'FERNANDO MAURICIO','Gama, foi repassado a compra dos e-Cnpjs A3 para o Flávio que implatará no sistema MIRA. Estou esperando uma resposta deles quanto a esta implementação.','',5,'2012-12-13','13:46:00',1,2),(9,70,1,174,'FERNANDO MAURICIO','Edilene, boa tarde. Devido a algumas realocações de setores e identificação para impressões. Alteramos o seu ID e SENHA para:\n\nLogin: GTH-EDILENE\nSenha: 1234\n\nSeu usuário poderá ser inserido em IMPRESSORAS E APARELHOS DE FAX > PREFERENCIAS DE IMPRESSÃO > AVANÇADO > CONTABILIDADE DE TRABALHO.\n\nCaso, tenhas dúvidas de como chegar aí, por favor me chame no spark. ','',5,'2012-12-13','13:50:56',1,2),(10,75,1,174,'FERNANDO MAURICIO','Anderson, poderia me enviar um print da tela do erro?','',5,'2012-12-14','11:32:23',1,2),(11,75,1,223,'ANDERSON ROSARIO','conformee solicitaçõa segue print','MXM.doc',10,'2012-12-14','14:08:26',2,2),(12,75,1,174,'FERNANDO MAURICIO','Seu usuário estava travado, poderia aguardar 5 minutos e realizar o login novamente? Entrei em contato a Equipe MXM para reiniciarem os acessos.','',5,'2012-12-14','14:18:02',1,2),(13,75,1,223,'ANDERSON ROSARIO','tudo certo. obrigado....','',10,'2012-12-14','14:26:18',2,2),(14,75,1,174,'FERNANDO MAURICIO','Deu certo Anderson? Podemos encerrar o chamado?','',8,'2012-12-14','15:10:50',1,2),(15,77,1,174,'FERNANDO MAURICIO','TESTE PARA VERIFICAR SE CHEGA O E-MAIL.','',10,'2012-12-14','15:34:21',2,2),(16,77,1,208,'LELIOMAR PICANCO','teste','',5,'2012-12-14','15:31:24',1,2),(17,77,1,208,'LELIOMAR PICANCO','teste2','',5,'2012-12-14','15:35:34',1,2),(18,77,1,208,'LELIOMAR PICANCO','teste3','',5,'2012-12-14','15:35:55',1,1),(19,82,1,174,'FERNANDO MAURICIO','Ticket criado junto ao MS. Segue o ticket....','Suporte #8989.jpg',5,'2012-12-18','14:56:44',1,2),(20,82,1,174,'FERNANDO MAURICIO','Ticket criado junto ao MS. Segue o ticket....','Suporte.jpg',5,'2012-12-18','14:59:00',1,2),(21,70,1,174,'FERNANDO MAURICIO','Edilene, podemos encerrar este chamado?','',5,'2012-12-18','15:05:39',1,2),(22,5,1,174,'FERNANDO MAURICIO','Em conversa com o Thiago pelo telefone, o mesmo me informou que falará com o Giulliano, coordenador Equipe Mira, para quais providências tomarem. Uma vez que, estamos dependendo deles agora pois já estamos com os certificados digitais em mãos.','',5,'2012-12-18','15:09:18',1,2),(23,83,1,174,'FERNANDO MAURICIO','Seu ip foi liberado para acessar os sites e videos.','',5,'2012-12-18','16:12:50',1,2),(24,85,1,217,'RYCKSON SILVA','ANEXO DEPILAÇÃO PRONATEC DA SOLICITAÇÃO 85','depilação .rar',10,'2012-12-19','10:28:17',2,1),(25,82,1,174,'FERNANDO MAURICIO','Cecília, segue resposta de MS. Essa implementação ocorrerá na próxima atualização.\n\nImplementação:\nAo checar o campo Permitir Pronatec, também será checado o Validar Assist. Estudantil.\nAo checar o campo Validar Assist. Estudantil, se o Permitir Pronatec não estiver checado então emite mensagem de erro.\n\n\nPodemos encerrar este chamado?','',5,'2012-12-19','10:33:28',1,2),(26,107,1,149,'CINTHIA SILVA','Solicito ainda que este mesmo software (DEDOS EM MOVIMENTO) seja instalado nos computadores do CFP PF para uso no módulo de Digitação. Se possível até o dia 25/01/13, pois dia 28/01 iniciará o módulo. Grata.','',10,'2013-01-09','09:13:34',2,2),(27,97,1,105,'NEILON MÁRCIO BATISTA DA SILVA','Atendimento feito com sucesso.\r\n\r\nFavor encerrar o chamado.','',10,'2013-02-22','15:17:31',2,2);
/*!40000 ALTER TABLE `historicosolicitacaogic_hisgi` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-07-02 17:13:35
