CREATE DATABASE  IF NOT EXISTS `suporte_banco_teste` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `suporte_banco_teste`;
-- MySQL dump 10.13  Distrib 5.6.17, for Win32 (x86)
--
-- Host: 127.0.0.1    Database: suporte_banco_teste
-- ------------------------------------------------------
-- Server version	5.6.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `forum`
--

DROP TABLE IF EXISTS `forum`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mensagem` text NOT NULL,
  `data` date NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `solicitacao_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`solicitacao_id`),
  KEY `fk_forum_solicitacao1_idx` (`solicitacao_id`),
  CONSTRAINT `fk_forum_solicitacao1` FOREIGN KEY (`solicitacao_id`) REFERENCES `solicitacao` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum`
--

LOCK TABLES `forum` WRITE;
/*!40000 ALTER TABLE `forum` DISABLE KEYS */;
INSERT INTO `forum` VALUES (1,'Foi instalado o nero 7,  mas não reconheceu o gravado na maquina vou testar com outra versão do nero.','2013-10-23',94,3),(2,'O problema que está ocorrendo é no plano desta turma. A indicação metodológica da VIVÊNCIA PROFISSIONAL está como \"teórica/prática\" você terá que solicitar a DEP que altere no plano para \"Prática Supervisionada - Empresa\". Peço que me envie um feedback por aqui para verificar se ocorreu tudo bem quando a DEP realizar a alteração.','2013-10-23',129,21),(13,'Robson, realizamos a correção da inserção deste docente. Peço que verifique e se estiver tudo certo, finalize este chamado. Se não, me informe o problema...','2013-10-23',129,18),(14,'Fernando, bom dia! \r\nVc colocou o ministrante apenas segundo bloco, entretanto precisamos que o referido ministrante esteja cadastras em todos os blocos temático desta turma','2013-10-25',43,18),(15,'Fernando,\r\n\r\nO plano foi corrigido pela DEP. Tudo ok. Obrigado pelo retorno.','2013-10-25',153,21),(16,'ELTON','2013-10-25',163,35),(17,'FERNANDO','2013-10-25',129,35),(18,'testendo email','2013-10-25',163,30),(19,'testendo email','2013-10-25',163,30),(20,'USUÁRIO ALTERANDO','2013-10-25',163,33),(21,'Userasd','2013-10-25',163,33),(22,'asd','2013-10-25',163,35),(23,'Técnico','2013-10-25',163,35),(24,'técnico','2013-10-25',163,35),(25,'técnicoasd','2013-10-25',163,35),(26,'técnicoasd','2013-10-25',163,35),(27,'técnicoasd','2013-10-25',163,35),(28,'teste','2013-10-25',163,33),(29,'wer','2013-10-25',163,35),(30,'wer','2013-10-25',163,35),(31,'werer','2013-10-25',163,35),(32,'asdf','2013-10-25',163,35),(33,'asdf','2013-10-25',163,35),(34,'asdfsdf','2013-10-25',163,35),(35,'ad','2013-10-25',163,35),(36,'Verifiquei que o problema está entre o pc e a cadeira.','2013-10-25',129,36),(37,'ELTON TÈCNICO','2013-10-28',163,38),(38,'ELTON USUÁRIO','2013-10-28',163,38),(39,'asd','2013-10-28',163,38),(40,'asdasd','2013-10-28',163,38),(41,'37','2013-10-28',163,37),(42,'37','2013-10-28',163,37),(43,'Elton Técnico','2013-10-28',163,39),(44,'teste','2013-10-28',163,39),(45,'Elton técnico','2013-10-28',163,39),(46,'asd','2013-10-28',163,39),(47,'asd','2013-10-28',163,39),(48,'asd','2013-10-28',163,39),(49,'asd','2013-10-28',163,39),(50,'asdasd','2013-10-28',163,39),(51,'FERNANDO','2013-10-28',129,39),(52,'asd','2013-10-28',129,39),(53,'aw','2013-10-28',129,39),(54,'aw','2013-10-28',129,39),(55,'teste','2013-10-28',129,39),(56,'fernando usuário','2013-10-28',129,39),(57,'asd','2013-10-28',129,39),(58,'ELTON','2013-10-28',163,39),(59,'wwww','2013-10-28',163,39),(60,'asdasd','2013-11-07',163,38),(61,'ELTON','2013-11-07',163,38),(62,'<ul>\r\n	<li>\r\n		Elton</li>\r\n	<li>\r\n		Teste</li>\r\n	<li>\r\n		teste</li>\r\n	<li>\r\n		&nbsp;</li>\r\n</ul>\r\n','2014-02-26',163,38),(63,'<p style=\"text-align: center;\">\r\n	Elton</p>\r\n<p style=\"text-align: center;\">\r\n	&nbsp;</p>\r\n<p style=\"text-align: center;\">\r\n	&nbsp;</p>\r\n<p style=\"text-align: center;\">\r\n	<span style=\"background-color:#ff0000;\">asdasd</span></p>\r\n','2014-02-26',163,38),(64,'<p>\r\n	<img src=\"http://1.gravatar.com/avatar/5f010b74541d33bb19241cb6a3289387?s=100&amp;r=pg&amp;d=mm\" />&nbsp;Imgem teste</p>\r\n','2014-02-26',163,38),(65,'<p>\r\n	<img src=\"http://1.gravatar.com/avatar/a82181c1c41aa47fb6ed917592d24f92?s=100&amp;r=pg&amp;d=mm\" /></p>\r\n','2014-02-26',163,38),(66,'','2014-02-26',163,38);
/*!40000 ALTER TABLE `forum` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-07-02 17:13:42
