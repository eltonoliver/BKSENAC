CREATE DATABASE  IF NOT EXISTS `db_psg` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `db_psg`;
-- MySQL dump 10.13  Distrib 5.6.17, for Win32 (x86)
--
-- Host: 127.0.0.1    Database: db_psg
-- ------------------------------------------------------
-- Server version	5.6.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `comunicado`
--

DROP TABLE IF EXISTS `comunicado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comunicado` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nomeComunicado` varchar(145) NOT NULL,
  `arquivoComunicado` varchar(145) NOT NULL,
  `data` date DEFAULT NULL,
  `edital_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`edital_id`),
  KEY `fk_comunicado_edital1_idx` (`edital_id`),
  CONSTRAINT `fk_comunicado_edital1` FOREIGN KEY (`edital_id`) REFERENCES `edital` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comunicado`
--

LOCK TABLES `comunicado` WRITE;
/*!40000 ALTER TABLE `comunicado` DISABLE KEYS */;
INSERT INTO `comunicado` VALUES (1,'COMUNICADO DE CANCELAMENTO','e7126-comunicado-de-cancelamento-turma-de-aperf-bartender.pdf',NULL,54),(2,'COMUNICADO - edital 43.2014 CIN','2b0f1-comunicado.pdf',NULL,66),(3,'Comunicado de Prorrogação das Inscrições','5ea7e-comunicado.pdf',NULL,85),(4,'Comunicado de cancelamento do edital','e1939-comunicado-de-cancelamento.pdf',NULL,97);
/*!40000 ALTER TABLE `comunicado` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-07-02 17:13:51
