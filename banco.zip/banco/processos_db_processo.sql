CREATE DATABASE  IF NOT EXISTS `processos_db` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `processos_db`;
-- MySQL dump 10.13  Distrib 5.6.17, for Win32 (x86)
--
-- Host: 127.0.0.1    Database: processos_db
-- ------------------------------------------------------
-- Server version	5.6.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `processo`
--

DROP TABLE IF EXISTS `processo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `processo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` varchar(100) NOT NULL,
  `data` date NOT NULL,
  `numeroEdital` varchar(80) NOT NULL,
  `objetivo` text NOT NULL,
  `idUsuario` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `modalidade_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`modalidade_id`),
  KEY `fk_processo_modalidade1_idx` (`modalidade_id`),
  CONSTRAINT `fk_processo_modalidade1` FOREIGN KEY (`modalidade_id`) REFERENCES `modalidade` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `processo`
--

LOCK TABLES `processo` WRITE;
/*!40000 ALTER TABLE `processo` DISABLE KEYS */;
INSERT INTO `processo` VALUES (4,'Processo de Seleção para Arquiteto - Manaus','2014-01-07','001/2014','<p>\r\n	Atender as demandas da Institui&ccedil;&atilde;o no setor de obras, projetos e manuten&ccedil;&atilde;o.</p>\r\n',NULL,1,2),(5,'Processo de seleção para atender as demandas das unidade de Manaus','2014-01-10','002/2014','<p>\r\n	Atender as demandas das unidades de ensino do municipio de Manaus.</p>\r\n',NULL,1,2),(6,'Processo de seleção para atender as demandas da unidade de Parintins.','2014-01-10','003/2014','<p>\r\n	Processo de sele&ccedil;&atilde;o para atender a unidade de Parintins e Boa Vista do Ramos.</p>\r\n',NULL,1,2),(7,'Processo Seletivo para atender as demandas da unidade de Manacapuru/Iranduba e Cacau Pirera.','2014-01-10','004/2014','<p>\r\n	Processo de sele&ccedil;&atilde;o para atender as demandas da unidade remota de Cacau Pirera e de Iranduba, al&eacute;m do docente de ingl&ecirc;s de Manacapuru.</p>\r\n',NULL,1,2),(16,'Processo de seleção para Manaus e Presidente Figueiredo','2014-03-09','011/2014','<p>\r\n	Atender as demandas dos cursos realizados em Presidente Figueiredo e Manaus.</p>\r\n',NULL,1,2),(17,'Processo de seleção para Parintins e Urucará','2014-03-09','012/2014','<p>\r\n	Atender as demandas de Parintins e Urucar&aacute;.</p>\r\n',NULL,1,2),(18,'Processo de seleção para Manacapuru, Cacau Pirera e Iranduba','2014-03-09','013/2014','<p>\r\n	Atender as demandas dos munic&iacute;pios.</p>\r\n',NULL,1,2),(19,'Atender as demandas das unidades de Manaus, Tefé e Presidente Figueiredo.','2014-03-11','014/2014','<p>\r\n	Atender as demandas das unidade de Manaus e de Tef&eacute; e dos cursos da unidade remota localizada no municipio de Presidente Figueiredo.</p>\r\n',NULL,1,2),(20,'Atender as demandas da unidade de Manaus','2014-02-09','005/2014','<p>\r\n	Processo Seletivo para atender as unidades de Manaus nos seguintes cargos de: Assistente T&eacute;cnico, Agente Administrativo - <strong>PCD</strong> e Auxiliar de Servi&ccedil;os Gerais Servente / Manuten&ccedil;&atilde;o.</p>\r\n',NULL,1,2),(21,'Processo Seletivo para Tefé','2014-02-09','006/2014','<p>\r\n	Processo de Sele&ccedil;&atilde;o para atuar em <strong>Tef&eacute;</strong> nos seguintes cargos: Docente de Turismo e Auxiliar de Servi&ccedil;os Gerais - Vigia.</p>\r\n',NULL,1,2),(22,'Processo Seletivo para Manacapuru','2014-02-09','007/2014','<p>\r\n	Processo de Sele&ccedil;&atilde;o para atuar em <strong>Manacapuru</strong> nos seguintes cargos: Docente de Ingl&ecirc;s e Docente de Sa&uacute;de e Seguran&ccedil;a no Trabalho.</p>\r\n',NULL,1,2),(23,'Processo Seletivo para Coari','2014-02-09','008/2014','<p>\r\n	Processo de Sele&ccedil;&atilde;o para atuar em <strong>Coari</strong> nos seguintes cargos: Docente de Ingl&ecirc;s, Inform&aacute;tica e de Seguran&ccedil;a.</p>\r\n',NULL,1,2),(24,'Processo de Seleção para Manaus e Tefé','2014-02-23','009/2014','<p>\r\n	Processo de Sele&ccedil;&atilde;o para atuar em <strong>Manaus</strong> nos seguintes cargos: Docente de Espanhol, Inform&aacute;tica e Ingl&ecirc;s e no municipio de <strong>Tef&eacute;</strong> no seguinte cargo: Docente de Inform&aacute;tica.</p>\r\n',NULL,1,2),(25,'PROCESSO DE SELEÇÃO PARA IRANDUBA E COARI','2014-02-23','010/2014','<p>\r\n	Processo de Sele&ccedil;&atilde;o para atuar no municipio de <strong>Iranduba</strong> nos seguintes cargos:Docente de Gest&atilde;o e Ingl&ecirc;s.</p>\r\n<p>\r\n	Processo de Sele&ccedil;&atilde;o para atuar no municipio de <strong>Coari</strong> no seguinte cargo: Auxiliar de Servi&ccedil;os Gerais - Vigia.</p>\r\n',NULL,1,2),(26,'Atender unidades de Manaus, Cacau Pirera e Iranduba.','2014-03-16','015/2014','<p>\r\n	Atender as demandas das unidades de Manaus, Cacau Pirera e Iranduba.</p>\r\n',NULL,1,2),(27,'Atender as unidade de Manaus.','2014-03-23','016/2014','<p>\r\n	Edital pata atender as demandas das unidades de manaus.</p>\r\n',NULL,1,2),(28,'Processo de seleção Para atender as unidades de Manaus.','2014-04-06','017/2014','<p>\r\n	Atender as demandas de setores e das unidades das capital.</p>\r\n',NULL,1,2),(29,'Processo de Seleção Assistente Técnico TI','2013-07-28','014/2013','<p>\r\n	Processo Seletivo Senac/AM para o cargo de Assistente T&eacute;cnico de TI.</p>\r\n',NULL,2,2),(30,'Atender as demandas no muinicípios de Coari, Maués e Parintins.','2014-04-19','018/2014','<p>\r\n	Suprir as demandas dos cursos realizados nos municipios de Coari, Mau&eacute;s e Parintins.</p>\r\n',NULL,1,2),(31,'Processo para atender as unidades de Manaus','2014-05-04','019/2014','<p>\r\n	Atender as demandas da unidade de Turismo e Hospitalidade e a Ger&ecirc;ncia de Manuten&ccedil;&atilde;o.</p>\r\n',NULL,1,2);
/*!40000 ALTER TABLE `processo` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-07-02 17:13:34
