CREATE DATABASE  IF NOT EXISTS `db_apl` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `db_apl`;
-- MySQL dump 10.13  Distrib 5.6.17, for Win32 (x86)
--
-- Host: 127.0.0.1    Database: db_apl
-- ------------------------------------------------------
-- Server version	5.6.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `custounidadepadrao_cuunipa`
--

DROP TABLE IF EXISTS `custounidadepadrao_cuunipa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custounidadepadrao_cuunipa` (
  `cuunipa_codcuunipa` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cuunipa_codunidade` int(11) NOT NULL,
  `cuunipa_codtipdes` int(10) unsigned NOT NULL,
  `cuunipa_coddespesa` int(10) unsigned NOT NULL,
  `cuunipa_valor` double NOT NULL,
  `cuunipa_encargos` varchar(5) NOT NULL,
  PRIMARY KEY (`cuunipa_codcuunipa`),
  KEY `fk_cuunipa_codtipdes` (`cuunipa_codtipdes`),
  KEY `fk_cuunipa_coddespesa` (`cuunipa_coddespesa`),
  CONSTRAINT `fk_cuunipa_coddespesa` FOREIGN KEY (`cuunipa_coddespesa`) REFERENCES `despesa_des` (`des_coddespesa`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_cuunipa_codtipdes` FOREIGN KEY (`cuunipa_codtipdes`) REFERENCES `tipodespesa_tipdes` (`tipdes_codtipdes`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custounidadepadrao_cuunipa`
--

LOCK TABLES `custounidadepadrao_cuunipa` WRITE;
/*!40000 ALTER TABLE `custounidadepadrao_cuunipa` DISABLE KEYS */;
INSERT INTO `custounidadepadrao_cuunipa` VALUES (0,2,2,4,0,'20'),(1,29,2,1,9.39,'32.70'),(2,29,2,2,12.98,'32.70'),(3,29,2,3,16.43,'32.70'),(4,29,4,15,10,'0'),(5,14,2,1,9.39,'32.70'),(6,14,2,2,12.98,'32.70'),(7,14,2,3,16.43,'32.70'),(8,14,2,4,0,'20'),(9,29,2,4,0,'20'),(10,14,4,15,29.74,'0'),(11,17,2,1,9.39,'32.70'),(12,17,2,2,12.98,'32.70'),(13,17,2,3,16.43,'32.70'),(14,17,2,4,0,'20'),(15,17,4,15,31.26,'0'),(16,16,2,1,9.39,'32.70'),(17,16,2,2,12.98,'32.70'),(18,16,2,3,16.43,'32.70'),(19,16,2,4,0,'20'),(20,16,4,15,29.14,'0'),(21,25,2,1,9.39,'32.70'),(22,25,2,2,12.98,'32.70'),(23,25,2,3,16.43,'32.70'),(24,25,2,4,0,'20'),(25,25,4,15,30.43,'0'),(26,15,2,1,9.39,'32.70'),(27,15,2,2,12.98,'32.70'),(28,15,2,3,16.43,'32.70'),(29,15,2,4,0,'20'),(30,15,4,15,32.35,'0'),(31,18,2,1,9.39,'32.70'),(32,18,2,2,12.98,'32.70'),(33,18,2,3,16.43,'32.70'),(34,18,2,4,0,'20'),(35,18,4,15,24.9,'0'),(36,19,2,1,9.39,'32.70'),(37,19,2,2,12.98,'32.70'),(38,19,2,3,16.43,'32.70'),(39,19,2,4,0,'20'),(40,19,4,15,24.03,'0'),(41,22,2,1,9.39,'32.70'),(42,22,2,2,12.98,'32.70'),(43,22,2,3,16.43,'32.70'),(44,22,2,4,0,'20'),(45,22,4,15,32.87,'0'),(46,10,2,1,9.39,'32.70'),(47,10,2,2,12.98,'32.70'),(48,10,2,3,16.43,'32.70'),(49,10,2,4,0,'20'),(50,10,4,15,63.25,'0'),(51,2,2,1,9.39,'32.70'),(52,2,2,2,12.98,'32.70'),(53,2,2,3,16.43,'32.70'),(55,2,4,15,31.47,'0'),(56,30,2,1,9.39,'32.70'),(57,30,2,2,12.98,'32.70'),(58,30,2,3,16.43,'32.70'),(59,30,2,15,0,'20'),(60,30,4,15,10,'0'),(61,30,2,20,27.95,'33.82'),(62,30,2,21,37.24,'33.82'),(63,30,2,22,44.46,'33.82');
/*!40000 ALTER TABLE `custounidadepadrao_cuunipa` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-07-02 17:13:59
