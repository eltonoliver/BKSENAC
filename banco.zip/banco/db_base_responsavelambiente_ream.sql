CREATE DATABASE  IF NOT EXISTS `db_base` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `db_base`;
-- MySQL dump 10.13  Distrib 5.6.17, for Win32 (x86)
--
-- Host: 127.0.0.1    Database: db_base
-- ------------------------------------------------------
-- Server version	5.6.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `responsavelambiente_ream`
--

DROP TABLE IF EXISTS `responsavelambiente_ream`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `responsavelambiente_ream` (
  `ream_codunidade` int(10) unsigned NOT NULL,
  `ream_codcolaborador` int(10) unsigned NOT NULL,
  PRIMARY KEY (`ream_codunidade`,`ream_codcolaborador`),
  KEY `fk_ream_codunidade` (`ream_codunidade`),
  KEY `fk_ream_codcolaborador` (`ream_codcolaborador`),
  CONSTRAINT `fk_ream_codcolaborador` FOREIGN KEY (`ream_codcolaborador`) REFERENCES `colaborador_col` (`col_codcolaborador`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_ream_codunidade` FOREIGN KEY (`ream_codunidade`) REFERENCES `unidade_uni` (`uni_codunidade`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `responsavelambiente_ream`
--

LOCK TABLES `responsavelambiente_ream` WRITE;
/*!40000 ALTER TABLE `responsavelambiente_ream` DISABLE KEYS */;
INSERT INTO `responsavelambiente_ream` VALUES (1,241),(1,310),(2,24),(3,54),(3,247),(3,257),(4,14),(4,84),(5,228),(6,180),(6,292),(7,22),(7,351),(8,56),(8,105),(9,52),(10,155),(10,321),(11,18),(12,70),(12,74),(12,360),(13,12),(13,263),(14,31),(15,41),(16,65),(16,290),(17,73),(18,62),(18,156),(19,100),(20,28),(21,145),(22,123),(22,355),(23,93),(24,95),(25,152),(25,309),(26,104),(27,226),(28,110),(28,112),(28,314),(30,182),(30,259),(31,227),(32,242),(33,244),(34,252),(34,291),(35,253),(39,356),(41,358),(42,359),(43,361);
/*!40000 ALTER TABLE `responsavelambiente_ream` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-07-02 17:13:57
