CREATE DATABASE  IF NOT EXISTS `db_base` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `db_base`;
-- MySQL dump 10.13  Distrib 5.6.17, for Win32 (x86)
--
-- Host: 127.0.0.1    Database: db_base
-- ------------------------------------------------------
-- Server version	5.6.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `funcaomodulo_fumo`
--

DROP TABLE IF EXISTS `funcaomodulo_fumo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `funcaomodulo_fumo` (
  `fumo_codfuncao` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fumo_descricao` varchar(45) NOT NULL,
  `fumo_sobre` text,
  `fumo_codmodulo` int(10) unsigned NOT NULL,
  PRIMARY KEY (`fumo_codfuncao`),
  KEY `fk_fumo_codmodulo` (`fumo_codmodulo`),
  CONSTRAINT `fk_fumo_codmodulo` FOREIGN KEY (`fumo_codmodulo`) REFERENCES `modulos_mod` (`mod_codmodulo`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `funcaomodulo_fumo`
--

LOCK TABLES `funcaomodulo_fumo` WRITE;
/*!40000 ALTER TABLE `funcaomodulo_fumo` DISABLE KEYS */;
INSERT INTO `funcaomodulo_fumo` VALUES (1,'Protocolar Documentos - Enviar','Protocolar o Envio de Documentos',2),(2,'Protocolar Documentos - Receber','Receber Documentos Protocolados',2),(3,'Cadastrar Contratos','Função que permite ao usuário a administração de contratos',3),(4,'Pesquisa Geral de Contratos','Função que permite ao usuário a pesquisa de contratos independente do setor.',3),(5,'Pesquisa de Contratos Seu Setor','Função que permite ao usuário a pesquisa de contratos de seu setor apenas',3),(6,'Cadastro de Categoria do Material','Função que possibilita o cadastro de Categorias dos Materiais do Repositório',4),(7,'Cadastro de Editora','Função que possibilita o cadastro de Editoras',4),(8,'Cadastro de Tipos de Materiais',' Função que possibilita o cadastro de Tipos de Materiais',4),(9,'Cadastro de Materiais','Função que possibilita o cadastro de Materiais',4),(10,'Pesquisa de Materiais','Função que permite a visualização de materiais públicos cadastrados.',4),(11,'Cadastrar Eixos','Função que permite o cadastro de Eixos',5),(12,'Cadastrar Segmentos','Função que permite o cadastro de Segmentos',5),(13,'Cadastrar Tipo de Ação','Função que permite o cadastro de Tipos de Ação',5),(14,'Cadastrar Nível','Função que permite o cadastro de Níveis',5),(15,'Cadastrar Despesas','Função que permite o cadastro de Despesas',5),(16,'Cadastrar Custos da Unidade','Função que permite o cadastro de Custos da Unidade',5),(17,'Cadastrar Plano de Ação','Função que permite o cadastro de Planos de Ação',5),(18,'Cadastrar Fontes de Recurso','Função que permite o cadastro de Fontes de Recurso',5),(19,'Cadastrar Anos','Função que permite o cadastro de Anos',5),(20,'Cadastrar Planilhas de Curso','Função que permite o cadastro de Planilhas de Curso',5),(21,'Analisar Planilhas','Função que permite a análise de Planilhas',5),(22,'Cadastrar Solicitações de Contrato',NULL,3),(23,'Pesquisar Títulos Vencidos e a Vencer',NULL,3),(24,'Pesquisar Solicitações de Contrato',NULL,3),(25,'Controlar Solicitações SECAD',NULL,2),(26,'Atendimento de Solicitações SECAD',NULL,2),(27,'Controlar Solicitações GIC',NULL,2),(28,'Atendimento de Solicitações GIC',NULL,2),(29,'Configurar Entrada de Dados Modelo A',NULL,5),(30,'Controle de Planilhas e Modelos A',NULL,5),(33,'CADASTRAR SOLICITAÇÕES','utilizado por usuários para efetuar os chamados',6),(34,'GERENCIAR SOLICITAÇÕES','utilizado pelo responsável do setor para responder as solicitações dos usuários.',6);
/*!40000 ALTER TABLE `funcaomodulo_fumo` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-07-02 17:13:54
