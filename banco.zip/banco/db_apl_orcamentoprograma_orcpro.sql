CREATE DATABASE  IF NOT EXISTS `db_apl` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `db_apl`;
-- MySQL dump 10.13  Distrib 5.6.17, for Win32 (x86)
--
-- Host: 127.0.0.1    Database: db_apl
-- ------------------------------------------------------
-- Server version	5.6.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `orcamentoprograma_orcpro`
--

DROP TABLE IF EXISTS `orcamentoprograma_orcpro`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orcamentoprograma_orcpro` (
  `orcpro_codorcpro` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `orcpro_codigo` varchar(15) NOT NULL,
  `orcpro_titulo` varchar(50) NOT NULL,
  `orcpro_identificacao` int(11) NOT NULL,
  `orcpro_codtipo` int(10) unsigned NOT NULL,
  PRIMARY KEY (`orcpro_codorcpro`),
  KEY `fk_orcpro_codtipo` (`orcpro_codtipo`),
  CONSTRAINT `fk_orcpro_codtipo` FOREIGN KEY (`orcpro_codtipo`) REFERENCES `tipodespesaorcamento_tiporc` (`tiporc_codtipo`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orcamentoprograma_orcpro`
--

LOCK TABLES `orcamentoprograma_orcpro` WRITE;
/*!40000 ALTER TABLE `orcamentoprograma_orcpro` DISABLE KEYS */;
INSERT INTO `orcamentoprograma_orcpro` VALUES (1,'3.1.90.11','VENC. E VANTAGENS FIXAS - PESSOAL CIVIL',111,1),(2,'3.1.90.13','OBRIGAÇÕES PATRONAIS',113,1),(3,'3.1.90.16','OUTRAS DESP. VARIÁVEIS - PESSOAL CIVIL',116,1),(4,'3.1.90.94','INDENIZAÇÕES TRABALHISTAS',194,1),(5,'3.4.90.14','DIÁRIAS - PESSOAL CIVIL',414,1),(6,'3.4.90.30','MATERIAL DE CONSUMO',430,1),(7,'3.4.90.33','PASSAGENS E DESPESA COM LOCOMOÇÃO',433,1),(8,'3.4.90.36','OUTROS SERVIÇOS TERC. PESSOA FÍSICA',436,1),(9,'3.4.90.39','OUTROS SERVIÇOS TERC. PESSOA JURÍDICA',439,1),(10,'3.4.90.47','OBRIGAÇÕES TRIBUTÁRIA E CONRIBUTIVAS',447,1),(11,'4.5.90.51','OBRAS E INSTALAÇÕES',551,2),(12,'4.5.90.52','EQUIPAMENTOS E MATERIAL PERMANENTE',552,2),(13,'4.6.90.61','AQUISIÇÃO DE IMÓVEIS',661,2),(14,'4.6.90.64','AQUISIÇÃO DE TÍTULOS RCI',664,2),(15,'4.6.90.66','CONCESSÃO DE EMPRÉSTIMOS',666,2),(16,'4.7.90.79','OUTRAS AMORTIZAÇÕES',779,2),(17,'4.9.50.41','CONTRIBUIÇÕES',941,2),(18,'4.9.50.42','AUXÍLIOS',942,2);
/*!40000 ALTER TABLE `orcamentoprograma_orcpro` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-07-02 17:14:02
