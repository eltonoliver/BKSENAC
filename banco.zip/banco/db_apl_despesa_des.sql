CREATE DATABASE  IF NOT EXISTS `db_apl` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `db_apl`;
-- MySQL dump 10.13  Distrib 5.6.17, for Win32 (x86)
--
-- Host: 127.0.0.1    Database: db_apl
-- ------------------------------------------------------
-- Server version	5.6.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `despesa_des`
--

DROP TABLE IF EXISTS `despesa_des`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `despesa_des` (
  `des_coddespesa` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `des_descricao` varchar(70) NOT NULL,
  `des_codtipdes` int(10) unsigned NOT NULL,
  PRIMARY KEY (`des_coddespesa`),
  KEY `fk_des_codtipdes` (`des_codtipdes`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `despesa_des`
--

LOCK TABLES `despesa_des` WRITE;
/*!40000 ALTER TABLE `despesa_des` DISABLE KEYS */;
INSERT INTO `despesa_des` VALUES (1,'Hora Aula com Docente Nível Médio',2),(2,'Hora Aula com Docente Nível Superior',2),(3,'Hora Aula com Docente Pós-Graduação',2),(4,'Hora Aula com Prestador',2),(5,'Hora Aula',1),(6,'Encargos',1),(7,'Diárias',1),(8,'Material de Consumo',1),(9,'Material Didático',1),(10,'Passagens Urbanas',1),(11,'Passagens Interurbanas',1),(12,'Hospedagem',1),(13,'Divulgação',1),(14,'Outras Despesas',1),(15,'Custo Médio Semi-Direto',4),(16,'Curso in Company',4),(17,'Despesas Indiretas',3),(18,'Seguro dos Alunos',1),(20,'Hora Aula com Docente Nivel Superior - Especialista',2),(21,'Hora Aula com Docente Nivel Superior - Mestre',2),(22,'Hora Aula com Docente Nivel Superior - Doutor',2),(23,'Diárias',1),(24,'Pessoa Jurídica',1),(25,'Equipamentos',1),(26,'Transporte',1);
/*!40000 ALTER TABLE `despesa_des` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-07-02 17:14:03
