CREATE DATABASE  IF NOT EXISTS `suporte_banco_teste` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `suporte_banco_teste`;
-- MySQL dump 10.13  Distrib 5.6.17, for Win32 (x86)
--
-- Host: 127.0.0.1    Database: suporte_banco_teste
-- ------------------------------------------------------
-- Server version	5.6.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `solicitacao`
--

DROP TABLE IF EXISTS `solicitacao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `solicitacao` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descricao_equi` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `descricao_servico` text CHARACTER SET utf8,
  `anexo` varchar(190) CHARACTER SET utf8 DEFAULT NULL,
  `local_servico` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `data_solicitacao` date NOT NULL,
  `data_atualizacao` date DEFAULT NULL,
  `data_finalizacao` date DEFAULT NULL,
  `situacao_id` int(11) NOT NULL DEFAULT '1',
  `prioridade_id` int(11) NOT NULL DEFAULT '1',
  `id_suporte` int(11) DEFAULT NULL,
  `sistemas_id` int(11) DEFAULT NULL,
  `patrimonio` int(8) DEFAULT NULL,
  `tipo` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_solicitacao_equi_situacao1_idx` (`situacao_id`),
  KEY `fk_solicitacao_equi_prioridade1_idx` (`prioridade_id`),
  KEY `fk_solicitacao_equi_sistemas1_idx` (`sistemas_id`),
  CONSTRAINT `fk_solicitacao_equi_prioridade1` FOREIGN KEY (`prioridade_id`) REFERENCES `prioridade` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_solicitacao_equi_sistemas1` FOREIGN KEY (`sistemas_id`) REFERENCES `sistemas` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_solicitacao_equi_situacao1` FOREIGN KEY (`situacao_id`) REFERENCES `situacao` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solicitacao`
--

LOCK TABLES `solicitacao` WRITE;
/*!40000 ALTER TABLE `solicitacao` DISABLE KEYS */;
INSERT INTO `solicitacao` VALUES (1,'MYSQL TESTE','<p>\r\n	Prezados,</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	Solicitamos manuten&ccedil;&atilde;o no microcomputador da colaboradora EDILENE NUNES - alocada na sala da Ger&ecirc;ncia do CTH. O equipamento n&atilde;o est&aacute; ligando.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	Att</p>\r\n',NULL,2,26,'2013-10-22',NULL,'2013-10-23',3,1,16,NULL,16867,1),(2,'Impressora','<p>\r\n	A impress&atilde;o n&atilde;o est&aacute; saindo na impressora localizada no RH, a mensagem que consta &eacute; que : Trabalho exclu&iacute;do - IDs cont. inval., sendo que ocorre o mesmo para mais 04 colegas do setor.</p>\r\n<p>\r\n	grata</p>\r\n',NULL,5,8,'2013-10-22',NULL,'2013-10-22',3,1,16,NULL,0,1),(3,'GABINETE PC','<p>\r\n	Hoje nao estou conseguindo imprimir. PS: o t&eacute;cnico j&aacute; &quot;ARRUMOU&quot;&nbsp; duas vezes em uma semana.</p>\r\n<p>\r\n	Preciso que meu COMPUTADOR GRAVE DVDS e n&atilde;o tenho privil&eacute;gio para isso.</p>\r\n<p>\r\n	<strong><em>obrigado!!!!</em></strong></p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<strong><em>ah: MEU PC NAO TEM PATRIMONIO O SERIAL &Eacute;&nbsp; ns:1a5990582</em></strong></p>\r\n<p>\r\n	&nbsp;</p>\r\n',NULL,13,71,'2013-10-22','2013-10-25',NULL,1,1,17,NULL,5990582,1),(4,'CPU','<p>\r\n	O referido equipamento n&atilde;o est&aacute; imprimindo, com isso solicitamos um t&eacute;cnico do setor da GIC, para o setor de Educa&ccedil;&atilde;o Corporativa.</p>\r\n',NULL,24,96,'2013-10-22',NULL,'2013-10-25',3,1,16,NULL,18009,1),(5,'Computador positivo do atendimento da Faculdade','<p>\r\n	<em>Solicitamos a visita de um t&eacute;cnico da GIC no dia 23.10.13, pela manh&atilde;, &nbsp;para disponibilizar o acesso &agrave; colaboradora Auzilene do CIN que estar&aacute; dando um apoio &agrave; Faculdade nesses pr&oacute;ximos dias. E, a mesma precisar&aacute; ter acesso as pastas do CIN.</em></p>\r\n<p>\r\n	<em>Desde j&aacute; agradecemos.</em></p>\r\n<p>\r\n	&nbsp;</p>\r\n',NULL,30,15,'2013-10-22',NULL,NULL,1,1,15,NULL,180084,1),(6,'Impressora - Sala da coordenação da Faculdade','<p>\r\n	Pedimos que revejam a configura&ccedil;&atilde;o da impressora instalada na Sala da Coordena&ccedil;&atilde;o da Faculdade.</p>\r\n<p>\r\n	A mesma est&aacute; imprimindo um relat&oacute;rio toda vez que digitaliza um documento.</p>\r\n<p>\r\n	Desde j&aacute; agradecemos.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n',NULL,30,15,'2013-10-22',NULL,NULL,1,1,17,NULL,18072,1),(7,'COMPUTADOR POSITIVO','<p>\r\n	Socilito reparo do teclado positivo. M&aacute;quina localizada na DEP (CDE).</p>\r\n<p>\r\n	N&uacute;mero de s&eacute;rie da m&aacute;quina: 1A3654234.</p>\r\n<p>\r\n	Att,</p>\r\n',NULL,11,93,'2013-10-22',NULL,NULL,1,1,17,NULL,17621,1),(8,'IMPRESSORA ZEBRADA','<p>\r\n	INSTALA&Ccedil;&Atilde;O E CONFIGURA&Ccedil;&Atilde;O DE IMPRESSORA ZEBRADA.</p>\r\n',NULL,6,120,'2013-10-22',NULL,NULL,1,1,16,NULL,19244,1),(10,'Impressora Bematch','<p>\r\n	impressora n&atilde;o esta impremindo correntamente na bobina.</p>\r\n',NULL,16,154,'2013-10-22','2013-10-22',NULL,1,1,3,NULL,11853,1),(11,'impressora Bematch','<p>\r\n	A impressora esta com problema de impress&atilde;o.</p>\r\n',NULL,16,154,'2013-10-22',NULL,NULL,1,1,17,NULL,11856,1),(13,NULL,'<p>\r\n	Prezados Senhores!</p>\r\n<p>\r\n	Solicito em carater de urg&ecirc;ncia verifica&ccedil;&atilde;o no email da supervisora da Unidade- Edilangela Freires pois a mesma n&atilde;o consegue mais abri-lo desde de segunda -feira dia 21/10/13. A urg&ecirc;ncia se d&aacute; devido alguns documentos terem que ser respondidos a DEP e a EDUCA&Ccedil;&Atilde;O COORPORATIVA dentro de alguns prazoz que est&atilde;o expirando.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	Atenciosamente</p>\r\n',NULL,25,123,'2013-10-23',NULL,NULL,1,1,3,12,NULL,2),(14,'MICROCOMPUTADOR POSITIVO COM PROCESSADOR INTEL; MEMORIA 4 GB;','<p>\r\n	Bom dia!!!</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	Solicito manuten&ccedil;&atilde;o do equipamento visto que o mesmo apresenta problema na mem&oacute;ria do mesmo. O referido computador foi enviado para recentemente manuten&ccedil;&atilde;o, no entanto, o problema persistiu e se agravou para problema na mem&oacute;ria RAM, de acordo com o colega Anderson.</p>\r\n<p>\r\n	Fico no aguardo,</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	Jociana Bel&eacute;m</p>\r\n',NULL,18,110,'2013-10-23',NULL,NULL,1,1,16,NULL,18007,1),(15,'Impressora','<p>\r\n	Problema na impress&atilde;o na maquina do colaborador Carlos Taveira.</p>\r\n<p>\r\n	Atenciosamente,</p>\r\n',NULL,7,36,'2013-10-23',NULL,'2013-10-23',3,1,16,NULL,NULL,1),(16,'NO BREAK','<p>\r\n	Bom dia,</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	Solicitamos a Instala&ccedil;&atilde;o de No break na balan&ccedil;a de pesagem de pratos do restaurante escola. A falta do equipamento t&ecirc;m ocasionado transtornos na pesagem durante as quedas de energia.</p>\r\n<p>\r\n	Att</p>\r\n',NULL,2,26,'2013-10-23',NULL,NULL,1,1,16,NULL,0,1),(17,'Notebook Emachines - GPE','<p>\r\n	Solicitamos a prepara&ccedil;&atilde;o do notebook do GPE para utiliza&ccedil;&atilde;o na balsa escola.</p>\r\n',NULL,10,44,'2013-10-23','2013-10-23','2013-10-25',3,1,17,NULL,17709,1),(18,NULL,'<p>\r\n	N&atilde;o estamos conseguindo colocar o Ministrante (prestador de servi&ccedil;os) a partir do segundo bloco&nbsp;da turma 88 Operador de Computador</p>\r\n<p>\r\n	Nome da docente: Shirlene da Silva Oliveira, Cod da Docente: 188488</p>\r\n<p>\r\n	Contato com Auxiliar Administrativo&nbsp;Claudia (92) 3361-1785</p>\r\n<p>\r\n	Aguardamos retorno</p>\r\n',NULL,15,43,'2013-10-23',NULL,NULL,1,1,3,1,NULL,2),(19,'Impressora da Supervisão - PF','<p>\r\n	Impressora com problema na hora de scanear.</p>\r\n',NULL,3,118,'2013-10-23',NULL,'2013-10-23',3,1,16,NULL,NULL,1),(21,NULL,'<div class=\"form-display-as-box\" id=\"descricao_servico_display_as_box\">\r\n	Boa Tarde,</div>\r\n<div class=\"form-input-box\" id=\"descricao_servico_input_box\">\r\n	<div class=\"readonly_label\" id=\"field-descricao_servico\">\r\n		<p>\r\n			Ao abrir a turma 184 para a unidade MPR, constatei diferen&ccedil;a na distribui&ccedil;&atilde;o dos dias letivos no bloco de Viv&ecirc;ncia. Geralmente turmas PAET n&atilde;o pede unidade nem depend&ecirc;ncia, somente dia de in&iacute;cio, hora aula, in&iacute;cio e t&eacute;rmino e os dias da semana. Solicito a verifica&ccedil;&atilde;o.&nbsp;</p>\r\n		<p>\r\n			Segue anexo print de como apareceu e como deve ser.</p>\r\n		<p>\r\n			Aguardo retorno o mais breve poss&iacute;vel.</p>\r\n		<p>\r\n			Atenciosamente.</p>\r\n		<p>\r\n			Tatiana Frota.</p>\r\n	</div>\r\n</div>\r\n<p>\r\n	&nbsp;</p>\r\n','381e9-turma-184-mpr.doc',28,153,'2013-10-23',NULL,NULL,1,1,3,1,NULL,2),(22,NULL,'<p>\r\n	VERIFICAR A POSSIBILIDADE DE ALTERAR CADASTRO DE PESSOA FISICA PARA ALUNO DE A&Ccedil;&Atilde;O EXTENSIVAS, RETIRAR A OBRIGATORIEDADE DA DATA DE NASCIMENTO MESMO PARA A&Ccedil;&Otilde;ES EXTENSIVAS QUE &Eacute; NECESSARIO EFETIVAR MATRICULA NA TURMA .</p>\r\n',NULL,28,68,'2013-10-23',NULL,NULL,1,1,3,1,NULL,2),(23,'computador positivo','<p>\r\n	Solicito que verifique a internet e a impress&atilde;o.</p>\r\n',NULL,34,180,'2013-10-23','2013-10-23','2013-10-23',3,1,17,NULL,16137,1),(25,NULL,'<p>\r\n	n&atilde;o consigo imprimir do MXM. preciso de ajuda. ( ALMOX. II) .</p>\r\n',NULL,2,147,'2013-10-23',NULL,'2013-10-23',3,1,17,2,NULL,2),(28,NULL,'<p>\r\n	Solicitamos que seja liberado aos funcioni&aacute;rios do setor de Recrutamento e Sele&ccedil;&atilde;o o acesso ao site do Tribunal de Justi&ccedil;a do Amazonas, afim de poder fazer as pesquisas referentes aos procecesso de sele&ccedil;&atilde;o.</p>\r\n',NULL,24,96,'2013-10-25',NULL,'2013-10-25',3,1,16,6,NULL,2),(29,'problema com a impressora','<p>\r\n	A impressora do sistema no computador n&atilde;o esta imprimindo</p>\r\n',NULL,5,192,'2013-10-25',NULL,'2013-10-25',3,1,16,NULL,NULL,1),(30,'324','asdasd',NULL,1,163,'2013-10-25',NULL,'2013-10-25',3,1,1,NULL,324324,1),(31,'asd','asd',NULL,1,163,'2013-10-25',NULL,'2013-10-25',3,1,1,NULL,123,1),(32,'testando','<p>\r\n	testando</p>\r\n',NULL,1,163,'2013-10-25',NULL,'2013-10-25',3,1,1,NULL,123,1),(33,'tytt','<p>\r\n	ytyty</p>\r\n',NULL,1,163,'2013-10-25',NULL,NULL,1,1,1,NULL,45343,1),(34,NULL,'<p>\r\n	asd</p>\r\n',NULL,1,163,'2013-10-25',NULL,NULL,1,1,1,8,NULL,2),(35,'asdasd','<p>\r\n	asdasdsad</p>\r\n',NULL,1,163,'2013-10-25',NULL,NULL,1,1,1,NULL,123123,1),(36,NULL,'<p>\r\n	Estamos com problema nesse certificado</p>\r\n',NULL,1,129,'2013-10-25',NULL,'2013-11-01',3,1,3,1,NULL,2),(37,NULL,'testando mensagem',NULL,1,163,'2013-10-28',NULL,NULL,1,1,1,13,NULL,2),(38,NULL,'<p>\r\n	AS</p>\r\n',NULL,1,163,'2013-10-28',NULL,NULL,1,1,1,13,NULL,2),(39,NULL,'<p>\r\n	Di&aacute;rio OnLine</p>\r\n',NULL,10,129,'2013-10-28',NULL,'2013-11-01',3,1,1,13,NULL,2);
/*!40000 ALTER TABLE `solicitacao` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-07-02 17:13:43
