CREATE DATABASE  IF NOT EXISTS `processos_db` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `processos_db`;
-- MySQL dump 10.13  Distrib 5.6.17, for Win32 (x86)
--
-- Host: 127.0.0.1    Database: processos_db
-- ------------------------------------------------------
-- Server version	5.6.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `resultados`
--

DROP TABLE IF EXISTS `resultados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resultados` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `resultado` varchar(145) DEFAULT NULL,
  `processo_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`processo_id`),
  KEY `fk_resultados_processo1_idx` (`processo_id`),
  CONSTRAINT `fk_resultados_processo1` FOREIGN KEY (`processo_id`) REFERENCES `processo` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=187 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resultados`
--

LOCK TABLES `resultados` WRITE;
/*!40000 ALTER TABLE `resultados` DISABLE KEYS */;
INSERT INTO `resultados` VALUES (46,'64e28-resultado_final_docente_de_beleza.pdf',5),(51,'a61b5-resultado_final_auxiliar_de_servicos_gerais.pdf',6),(52,'bcdae-resultado_final_docente_de_beleza.pdf',6),(53,'92c00-resultado_final_docente_de_informatica.pdf',6),(54,'8dc52-resultado_final_docente_de_moda.pdf',6),(55,'e76aa-resultado_final_docente_de_gestao_boa_vista_do_ramos.pdf',6),(57,'a594a-resultado_final_docente_de_turismo_iranduba_e_cacau_pirera.pdf',7),(58,'5a105-resultado_final_asg_manutencao.pdf',20),(60,'54680-resultado_final_asg_vigia_lb.pdf',21),(61,'8a5c2-resultado_final_docente_de_ingles.pdf',22),(62,'66f7f-resultado_docente_de_saude_e_seg_no_trab.pdf',22),(64,'958a2-resultado_final_docente_de_seguranca_bombeiro_civil.pdf',23),(65,'96a3a-resultado_final_docente_de_espanhol.pdf',24),(66,'0a3af-resultado_final_docente_de_informatica.pdf',24),(67,'b2e90-resultado_final_docente_de_ingles.pdf',24),(68,'d3bac-resultado_final_docente_de_gestao.pdf',25),(69,'63d29-resultado_final_docente_de_ingles.pdf',25),(70,'495ef-resultado_final_asg_vigia_coari.pdf',25),(72,'7bfc1-lista_selecionados---2a_fase_d._saude.pdf',18),(73,'ed412-resultado_final_agente_adm_iranduba_cacau_pirera.pdf',7),(74,'0439f-lista_selecionados---2a_fase_auxiliar_adm.pdf',19),(75,'2adba-resultado_final_docente_de_saude.pdf',18),(76,'8d3db-resultado_final_docente_de_informatica_tefe.pdf',24),(78,'d26fb-lista_selecionados---2a_fase_assistente_tecnico_tefe.pdf',19),(79,'3a72d-resultado_1a_fase_agente-administrativo_presidente_figueiredo.pdf',19),(80,'a7c52-resultado_final_agente_administrativo_presidente_figueiredo.pdf',19),(84,'32045-resultado_final_docente_beleza_presidente_figueiredo.pdf',16),(85,'dabf5-resultado_final_docente_gestao_presidente_figueiredo.pdf',16),(86,'35e3e-resultado_final_docente_turismo_presidente_figueiredo.pdf',16),(88,'72c14-lista_selecionados---3a_fase_auxiliar_adm.pdf',19),(89,'7b809-lista-selecionados---2a_fase_assistente_tecnico.pdf',27),(90,'459e2-lista_selecionados---2a_fase_agente_administrativo.pdf',26),(94,'7fc61-resultado_final_docente_beleza_mpr.pdf',17),(95,'ad05a-lista_selecionados---3a_fase_assistente_tecnico.pdf',27),(96,'4d154-resultado_1a_fase_analista_administrativo.pdf',26),(97,'99291-resultado_2a_fase_analista_administrativo.pdf',26),(98,'4d0a9-lista_selecionados---3a_fase_agente_administrativo.pdf',26),(99,'2e662-lista-selecionados---prova.pdf',29),(100,'58734-resultado-final.pdf',29),(102,'ab674-lista-selecionados---2a-fase-d.-nutricao-mpr.pdf',17),(103,'3b265-lista_selecionados---2a_fase_auxiliar_de_cozinha.pdf',27),(105,'9a54a-resultado_final_agente-adm.-caixa.pdf',26),(106,'df9b0-lista_selecionados---2a_fase_tecnico_em_informatica.pdf',28),(107,'029b6-lista_selecionados---3a_fase_tecnico_em_informatica.pdf',28),(108,'85079-lista_selecionados---2a_fase_asg_vigia_parintins.pdf',30),(110,'5ceef-lista_selecionados---2a_fase_asg_vigia.pdf',28),(111,'cb33b-lista_selecionados---2a_fase_enfermagem_urucara.pdf',17),(112,'02114-resultado_final_enfermagem_urucara.pdf',17),(113,'df1dc-lista_selecionados---3a_fase_asg_vigia.pdf',28),(114,'a1966-lista-selecionados---2a-fase-arquiteto.pdf',4),(115,'008c6-lista-selecionados---3a-fase-arquiteto.pdf',4),(116,'95634-lista-selecionados---resultado-final-arquiteto.pdf',4),(125,'50b5e-resultado_final_gastronomia.pdf',5),(128,'48f7c-resultado_final_docente_de_ingles.pdf',5),(131,'caab9-resultado_final_docente_de_turismo.pdf',5),(136,'73d3c-resultado-final-agente-administrativo.pdf',5),(139,'87cdd-resultado_final_asg_vigia_mpr.pdf',30),(140,'eebbe-resultado_final_assistente_tecnico_tefe.pdf',19),(145,'b5b2e-resultado_final_tecnico_em_informatica.pdf',28),(149,'d2364-resultado_final_assistente_tecnico.pdf',27),(151,'70e89-resultado_final_docente_de_ingles.pdf',7),(162,'a0e40-lista_selecionados---2a_fase_agente_adm_pcd.pdf',20),(168,'37e84-lista-selecionados---2a-fase-docente_de_ingles.pdf',22),(169,'778fd-lista-selecionados---2a-fase-d.-bombeiro-civil.pdf',23),(171,'0846e-lista-selecionados---2a-fase-d.-informatica_tefe.pdf',24),(175,'def25-lista-selecionados---2a-fase_asg_vigia_coari.pdf',25),(176,'2fc88-resultado_final_docente_de_seg_no_trabalho.pdf',16),(177,'d0439-lista_selecionados---2a_fase_auxiliar_de_servicos_gerais_servente.pdf',20),(178,'deb77-lista_selecionados---3a_fase_auxiliar_de_servicos_gerais_servente.pdf',20),(179,'35ccd-resultado_final_auxiliar_de_servicos_gerais_servente.pdf',20),(182,'c5364-lista_selecionados---2a_fase_assistente_tecnico_nutricao.pdf',31),(184,'c0f86-lista_selecionados---2a_fase_beleza_mpr.pdf',16),(185,'189a8-lista_selecionados---2a_fase_beleza_mpr.pdf',17),(186,'b5e44-lista_selecionados---3a_fase_assistente_tecnico.pdf',31);
/*!40000 ALTER TABLE `resultados` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-07-02 17:13:34
