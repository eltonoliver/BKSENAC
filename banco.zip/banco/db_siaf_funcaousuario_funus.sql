CREATE DATABASE  IF NOT EXISTS `db_siaf` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `db_siaf`;
-- MySQL dump 10.13  Distrib 5.6.17, for Win32 (x86)
--
-- Host: 127.0.0.1    Database: db_siaf
-- ------------------------------------------------------
-- Server version	5.6.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `funcaousuario_funus`
--

DROP TABLE IF EXISTS `funcaousuario_funus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `funcaousuario_funus` (
  `funus_codfunus` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `funus_codfuncao` int(10) unsigned NOT NULL,
  `funus_codcolaborador` int(10) unsigned NOT NULL,
  PRIMARY KEY (`funus_codfunus`),
  KEY `fk_funus_codfuncao` (`funus_codfuncao`),
  KEY `fk_funus_codcolaborador` (`funus_codcolaborador`),
  CONSTRAINT `fk_funus_codcolaborador` FOREIGN KEY (`funus_codcolaborador`) REFERENCES `unidadeusuario_unius` (`unius_codcolaborador`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_funus_codfuncao` FOREIGN KEY (`funus_codfuncao`) REFERENCES `funcao_fun` (`fun_codfuncao`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `funcaousuario_funus`
--

LOCK TABLES `funcaousuario_funus` WRITE;
/*!40000 ALTER TABLE `funcaousuario_funus` DISABLE KEYS */;
INSERT INTO `funcaousuario_funus` VALUES (1,8,1),(2,3,1),(3,4,1),(4,6,1),(5,7,1),(6,2,1),(7,1,1),(9,9,1),(10,5,2),(11,5,3),(12,9,4),(13,8,4),(14,3,4),(15,4,4),(16,6,4),(17,7,4),(21,5,5),(22,9,6),(23,8,6),(24,3,6),(25,4,6),(26,6,6),(27,7,6),(28,2,6),(29,1,6),(30,5,6),(31,8,7),(32,9,7),(33,3,7),(34,4,7),(35,6,7),(36,7,7),(37,2,7),(38,1,7),(39,5,7),(40,5,8),(41,9,9),(42,8,9),(43,3,9),(45,5,9),(46,5,4),(47,5,1),(48,5,10);
/*!40000 ALTER TABLE `funcaousuario_funus` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-07-02 17:13:49
