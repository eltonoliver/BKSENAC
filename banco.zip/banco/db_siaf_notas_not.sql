CREATE DATABASE  IF NOT EXISTS `db_siaf` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `db_siaf`;
-- MySQL dump 10.13  Distrib 5.6.17, for Win32 (x86)
--
-- Host: 127.0.0.1    Database: db_siaf
-- ------------------------------------------------------
-- Server version	5.6.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `notas_not`
--

DROP TABLE IF EXISTS `notas_not`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notas_not` (
  `not_codnota` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `not_nota` text NOT NULL,
  `nota_data` date NOT NULL,
  `not_codusuario` int(10) unsigned NOT NULL,
  `not_codunidade` int(10) unsigned NOT NULL,
  `not_dataregistro` date NOT NULL,
  PRIMARY KEY (`not_codnota`),
  KEY `fk_not_codusuario` (`not_codusuario`),
  KEY `fk_not_codunidade` (`not_codunidade`),
  CONSTRAINT `fk_not_codunidade` FOREIGN KEY (`not_codunidade`) REFERENCES `unidade_uni` (`uni_codunidade`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_not_codusuario` FOREIGN KEY (`not_codusuario`) REFERENCES `usuario_usu` (`usu_codusuario`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notas_not`
--

LOCK TABLES `notas_not` WRITE;
/*!40000 ALTER TABLE `notas_not` DISABLE KEYS */;
INSERT INTO `notas_not` VALUES (1,'O VALOR DA DESPESA COM OBRA DE 88.118,91 REFERE-SE AO PAGAMENTO DO TERCEIRO TERMO ADITIVO DA OBRA LOPES GONCALVES - CONSTRUTORA MEDINA','2011-09-16',2,1,'2011-10-10'),(2,'À Quota de Arrecadação do mês de setembro/11, em relação ao mês anterior houve uma redução na ordem de 0,95%, \r\n\r\nQuanto à transferência do numerário total, houve uma redução de 6,43%, em comparação ao mês de agosto/11, em função da amortização das despesas com o sistema MIRA (20.500,09), bem como, despesas com aquisição de livros, diárias/hospedagem e adesão ao Programa ELA do fabricante ADOBE para o CIN (Centro de Informática) (44.322,94).','2011-10-17',2,1,'2011-10-17'),(3,'Arrecadação Compulsória mês de setembro 2011 R$ 1.905.632,05','2011-10-14',6,2,'2011-11-29'),(6,'ESTE MÊS EFETUAMOS O PAGAMENTO DA OITVA MEDICAO DE OBRA E REFORMA DA FACULDADE SENAC NO VALOR DE R$150.753,83','2011-10-26',2,1,'2011-10-30'),(7,' Receita compulsória mês de outubro/2011 R$ 2.043.754,80','2011-11-17',6,2,'2011-11-23'),(8,'Valores a Receber do Departamento Nacional por ocasião das Obras e Projetos no montante de R$ 3. 337.258,42','2011-10-31',4,2,'2011-11-29'),(9,'A DESPESA COM AQUISICAO DE EQUIPAMENTOS NO MES, REFERE-SE A COMPRA DE DIVERSOS EQUIPAMENTOS PARA AS UNIDADES DO:\r\nPEQUENO FRANCO - PARINTINS - COARI E SEDE ADMINISTRATIVA','2011-12-16',2,1,'2012-01-13'),(10,'ESTE MES O VALOR COM ENCARGOS E SALARIOS TEVE UM AUMENTO EM VIRTUDE DO PAGAMENTO DE FERIAS E 13SALARIO DOS COLABORADORES.','2011-12-16',2,1,'2012-01-13'),(11,'DESPESAS COM OBRAS REFEREM-SE A:\r\nGRAFITE ENGENHARIA - R$104.744,15 - SERVICOS EXECUTADOS NA OBRA DE MANACAPURU','2012-03-31',2,1,'2012-05-02'),(12,'A DESPESA DE CAPITAL COM EQUPAMENTOS NO VALOR DE R$10.153,00 REFERE-SE A COMPRA DE MAQUINA DE BACKUP PARA OS SERVIDORES DA REDE METROPOLITANA DE MANAUS E INTERIOR.\n','2012-04-30',2,1,'2012-05-02');
/*!40000 ALTER TABLE `notas_not` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-07-02 17:13:49
