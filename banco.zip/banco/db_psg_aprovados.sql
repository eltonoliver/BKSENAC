CREATE DATABASE  IF NOT EXISTS `db_psg` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `db_psg`;
-- MySQL dump 10.13  Distrib 5.6.17, for Win32 (x86)
--
-- Host: 127.0.0.1    Database: db_psg
-- ------------------------------------------------------
-- Server version	5.6.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `aprovados`
--

DROP TABLE IF EXISTS `aprovados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aprovados` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nomeLista` varchar(145) NOT NULL,
  `arquivoLista` varchar(145) NOT NULL,
  `data` date DEFAULT NULL,
  `edital_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`edital_id`),
  KEY `fk_aprovados_edital1_idx` (`edital_id`),
  CONSTRAINT `fk_aprovados_edital1` FOREIGN KEY (`edital_id`) REFERENCES `edital` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aprovados`
--

LOCK TABLES `aprovados` WRITE;
/*!40000 ALTER TABLE `aprovados` DISABLE KEYS */;
INSERT INTO `aprovados` VALUES (22,'Lista de classificados - edital 09.2014 LR','52ce1-lista-classificados-edital-09.2014-lr.pdf',NULL,14),(23,'Lista de classificados 1ª etapa','63c27-lista-de-classificados---edital-12.2014-cin.pdf',NULL,20),(24,'Lista de Classificados 2ª etapa','e3c09-lista-de-classificados---edital-12.2014-cin---2a-etapa.pdf',NULL,20),(29,'Lista de classiicados','5961d-lista-de-classificados.-edital-15.2014-cin.pdf',NULL,23),(30,'Lista de Classificados - edital 21.2014 CIN','c76a5-lista-dos-classificados-edital-21.2014-cin.pdf',NULL,30),(31,'Lista de classificados - edital 17.2014 PJP','05b08-lista-de-classificados---edital-17.2014-pjp.pdf',NULL,26),(33,'Lista de classificados - edital 30.2014 MBI','b222f-lista-de-classificados---edital-30.2014-mbi.pdf',NULL,39),(43,'Lista de classificados - edital 25.2014 CIN','8ef33-lista-de-classificados---edital-25.2014-cin.pdf',NULL,34),(46,'Lista de classificados - edital 20.2014 CTH - copeiro','dc517-lista-de-classificados---edital-20.2014-cth.pdf',NULL,64),(47,'Lista de classificados - edital 19.2014 CTH','805a0-lista-de-classificados---edital-19.2014--tecnico-em-cozinha.pdf',NULL,28),(53,'Lista de classificados 4 - Nhamunda - edital 23.2014 MPR','65008-lista-de-classificados-4-=nhamunda---edital-23.2014-mpr.pdf',NULL,65),(59,'Lista de classificados - aperfeiçoamento para garçom','b5b04-lista-de-classificados---aperfeicoamento-para-garcom---edital-38.2014-cth.pdf',NULL,54),(60,'Lista de classificados - edital 24.2014 PF','db42b-lista-de-classificados-edital-24.2014-pf.pdf',NULL,41),(62,'Lista de classificados - edital 37.2014 LR','cd3f0-lista-de-classificados-edital-37.2014-lr.pdf',NULL,53),(67,'Lista de classificados - edital 46.2014 CTH','8e21c-lista-de-classificados---aperfeicoamento-para-garcom---edital-46.pdf',NULL,69),(72,'Lista de classificados - edital 50.2014 CTH','43b45-lista-de-classificados-recepcionista-em-meios-de-hospedagem-edital-50.pdf',NULL,74),(76,'Lista de classificados 1 - edital 55.2014 CTH','53a50-lista-de-classificados----tecnico-em-cozinha---edital-55.pdf',NULL,75),(77,'Lista de classificados - edital 59.2014 PJP','5113a-lista-de-classificados---edital-59.2014-pjp.pdf',NULL,87),(78,'Lista de classificados - edital 63.2014 LB','608d0-lista-de-classificados--tecnico-63.pdf',NULL,88),(79,'Lista de classificados - edital 56.2014 LB','a68fb-lista-de-classificados--ed-56.pdf',NULL,89),(80,'Lista de classificados - edital 62.2014 PF','61614-lista-de-classificados---edital-62.2014-pf.pdf',NULL,85),(81,'Lista de classificados - edital 61.2014 CTH','bf9bd-lista-de-classificados-edital-61-tec-eventos.pdf',NULL,95),(82,'Lista de classificados - edital 64.2014 JT','d6290-classificados-edital-64.2014---manicure-e-pedicure-psg-sesc.pdf',NULL,96),(83,'Lista de classificados - edital 64.2014 JT','d6290-classificados-edital-64.2014---manicure-e-pedicure-psg-sesc.pdf',NULL,96),(84,'Lista de classificados - edital 66.2014 CIN','e6cfc-lista-de-classificados---tecnicos.pdf',NULL,98);
/*!40000 ALTER TABLE `aprovados` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-07-02 17:13:50
