CREATE DATABASE  IF NOT EXISTS `db_ambiente` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `db_ambiente`;
-- MySQL dump 10.13  Distrib 5.6.17, for Win32 (x86)
--
-- Host: 127.0.0.1    Database: db_ambiente
-- ------------------------------------------------------
-- Server version	5.6.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbl_conteudo`
--

DROP TABLE IF EXISTS `tbl_conteudo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_conteudo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(145) NOT NULL,
  `imagem` varchar(145) DEFAULT NULL,
  `conteudo` text,
  `tbl_usuario_id` int(11) NOT NULL,
  `tbl_tipo_id` int(11) NOT NULL,
  `tbl_categoria_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`tbl_usuario_id`,`tbl_tipo_id`,`tbl_categoria_id`),
  KEY `fk_tbl_conteudo_tbl_usuario1_idx` (`tbl_usuario_id`),
  KEY `fk_tbl_conteudo_tbl_tipo1_idx` (`tbl_tipo_id`),
  KEY `fk_tbl_conteudo_tbl_categoria1_idx` (`tbl_categoria_id`),
  CONSTRAINT `fk_tbl_conteudo_tbl_categoria1` FOREIGN KEY (`tbl_categoria_id`) REFERENCES `tbl_categoria` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_tbl_conteudo_tbl_tipo1` FOREIGN KEY (`tbl_tipo_id`) REFERENCES `tbl_tipo` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_tbl_conteudo_tbl_usuario1` FOREIGN KEY (`tbl_usuario_id`) REFERENCES `tbl_usuario` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_conteudo`
--

LOCK TABLES `tbl_conteudo` WRITE;
/*!40000 ALTER TABLE `tbl_conteudo` DISABLE KEYS */;
INSERT INTO `tbl_conteudo` VALUES (1,'Inicio','768f8-slide1.jpg',NULL,2,2,10),(2,'Objetivos','e182f-slide2.jpg',NULL,2,2,10),(3,'Tópicos','94d59-slide3.jpg',NULL,2,2,10),(4,'História','b985d-slide4.jpg',NULL,2,2,10),(5,'Video',NULL,'<p>\r\n	<iframe allowfullscreen=\"\" frameborder=\"0\" height=\"415\" src=\"//www.youtube.com/embed/NPOBb9JQw1k\" width=\"730\"></iframe></p>\r\n',2,1,10),(6,'Conceito','52f01-slide5.jpg',NULL,2,2,10),(7,'Objetivo Geral','ac69e-slide6.jpg',NULL,2,2,10),(8,'Missão','ae6a5-slide7.jpg',NULL,2,2,10),(9,'Visão de Futuro','28e13-slide8.jpg',NULL,2,2,10),(10,'Principios','99a33-slide9.jpg',NULL,2,2,10),(11,'Visão e Fatores de Sucesso','07700-slide10.jpg',NULL,2,2,10),(12,'Diretrizes','aaa4c-slide11.jpg',NULL,2,2,10),(13,'Promoção Social','3e289-slide12.jpg',NULL,2,2,10),(14,'Orientação para o Mercado','41ba1-slide13.jpg',NULL,2,2,10),(15,'Inovação  e Gestão do Conhecimento','49857-slide14.jpg',NULL,2,2,10),(16,'Gestao Institucional','4b7bc-slide15.jpg',NULL,2,2,10),(17,'Imagem Institucional','e3cf2-slide16.jpg',NULL,2,2,10),(18,'CFP','757b7-slide17.jpg',NULL,2,2,10),(19,'Itinerários de Profissionalização','c4f0e-slide18.jpg',NULL,2,2,10),(20,'Video Amazonas',NULL,'<p>\r\n	<iframe allowfullscreen=\"\" frameborder=\"0\" height=\"405\" src=\"//www.youtube.com/embed/RmozDTdVxDQ\" width=\"720\"></iframe><br />\r\n	&nbsp;</p>\r\n',2,1,10),(21,'Estrutura Amazonas','24db9-slide19.jpg',NULL,2,2,10),(22,'Estrutura do DR/AM','1bfdb-slide20.jpg',NULL,2,2,10),(23,'Unidades Educacionais','86c24-slide21.jpg',NULL,2,2,10),(24,'Unidades Operativas','ed960-slide22.jpg',NULL,2,2,10),(25,'Gestão de Unidades II','4f040-slide23.jpg',NULL,2,2,10),(26,'Organograma I','710b1-org.jpg',NULL,2,2,12),(29,'Presidente','cf152-slide1.jpg',NULL,2,2,12),(30,'Diretora','957d9-slide2.jpg',NULL,1,2,12),(31,'Gerente Administrativo','06c60-slide3.jpg',NULL,1,2,12),(32,'Gerente Planejamento','89fb5-slide4.jpg',NULL,1,2,12),(33,'Gerente Educação Profissional','8a761-slide5.jpg',NULL,1,2,12),(34,'Gerência Financeira','a196c-slide6.jpg',NULL,1,2,12),(35,'Controle Interno','4fec3-slide7.jpg',NULL,1,2,12),(36,'Gerências Técnicas','bb44f-slide8.jpg',NULL,1,2,12),(37,'Gerências Administrativas I','7bb26-slide9.jpg',NULL,1,2,12),(38,'Gerências Administrativas II','d2239-slide10.jpg',NULL,1,2,12),(39,'Faculdade de Tecnologia','d0d95-slide11.jpg',NULL,1,2,12),(40,'CFP´s em Manaus','a6800-slide12.jpg',NULL,1,2,12),(41,'CFP´s - Múnicípios','9f946-slide13.jpg',NULL,1,2,12),(42,'Politicas de RH','028f8-slide29.jpg',NULL,1,2,11),(43,'Contratos, atestados e Justificativas','de9e2-slide30.jpg',NULL,1,2,11),(44,'Horário de Trabalho','e60f9-slide31.jpg',NULL,1,2,11),(45,'Faltas e Licenças','e1790-slide32.jpg',NULL,1,2,11),(46,'Benefícios','b0a9f-slide33.jpg',NULL,1,2,11),(47,'Responsabilidades do Colaborador','e1f26-slide34.jpg',NULL,1,2,11),(48,'Responsabilidades do Colaborador','f2d1c-slide35.jpg',NULL,1,2,11);
/*!40000 ALTER TABLE `tbl_conteudo` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-07-02 17:13:52
