CREATE DATABASE  IF NOT EXISTS `db_gde` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `db_gde`;
-- MySQL dump 10.13  Distrib 5.6.17, for Win32 (x86)
--
-- Host: 127.0.0.1    Database: db_gde
-- ------------------------------------------------------
-- Server version	5.6.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `protocolo_pro`
--

DROP TABLE IF EXISTS `protocolo_pro`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `protocolo_pro` (
  `pro_codprotocolo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pro_codcolaborador` int(11) NOT NULL,
  `pro_codunidade` int(11) NOT NULL,
  `pro_data` date NOT NULL,
  `pro_hora` varchar(12) NOT NULL,
  `pro_sobre` text,
  `pro_codtipo` int(10) unsigned NOT NULL,
  `pro_codsituacao` int(10) unsigned NOT NULL,
  PRIMARY KEY (`pro_codprotocolo`),
  KEY `fk_pro_codtipo` (`pro_codtipo`),
  KEY `fk_pro_codsituacao` (`pro_codsituacao`),
  CONSTRAINT `fk_pro_codsituacao` FOREIGN KEY (`pro_codsituacao`) REFERENCES `situacaoprotocolo_sipro` (`sipro_codsituacao`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_pro_codtipo` FOREIGN KEY (`pro_codtipo`) REFERENCES `tipodocumentacao_tipdo` (`tipdo_codtipo`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `protocolo_pro`
--

LOCK TABLES `protocolo_pro` WRITE;
/*!40000 ALTER TABLE `protocolo_pro` DISABLE KEYS */;
INSERT INTO `protocolo_pro` VALUES (1,32,1,'2010-12-15','11:36:39','Apenas teste da função de Protocolo Eletrônico no Sistema Gerenciador de Documentação Eletrônica',1,1),(2,84,4,'2010-12-17','10:34:19','ORDEM DE SERVIÇO 142/2010',1,2),(3,84,4,'2010-12-17','11:04:27','Agendas 2011',1,3),(4,47,15,'2010-12-20','15:01:35','COMPROVANTE DE DEPOSITO REF. RECEITA MIRA',1,3),(5,52,9,'2011-01-26','08:50:54','Banners, faixas',1,1),(6,52,9,'2011-01-26','08:51:31','Envio de Banners e Faixa',1,1),(7,54,3,'2011-03-04','14:46:16','inhinhinjinjjn',1,1),(8,14,4,'2011-04-13','11:55:45','FAX DN Nº 822/11 - Quota e Refiz de Março/2011',1,3),(9,14,4,'2011-04-13','11:58:33','FAX DN º 822/2011 - Quota Refiz Março/2011',1,3),(10,102,25,'2012-01-12','17:01:11','Soliciotação de demissão de colaborador',2,1),(11,135,25,'2012-02-23','07:55:20','Faltou SIstema no dia 17/02 - PJP - COARI AM',1,1),(12,1,1,'2012-04-18','15:27:58','Formulario de criação de login e senha.',1,3),(13,152,25,'2012-05-24','17:46:08','PAGAMENTO DE PRESTADORA DE SERVIÇO',1,1),(14,84,0,'2012-07-12','16:20:24','DIÁRIAS E PASSAGEM AÉREA PARA DRG E DIF',1,1),(15,227,31,'2013-01-25','17:17:14','AUTORIZAÇAO DESPESA VIAGEM ENGENHEIROS PARA FISCALIZAÇAO OBRA PARINTINS',1,1),(16,227,31,'2013-02-07','09:48:40','ADIANTAMENTO VIAGEM ITACOATIARA',1,1),(17,227,31,'2013-08-02','19:48:10','REMETENDO 4º TERMO ADITIVO OBRA CID NOVA',1,1),(18,227,31,'2013-09-12','17:42:44','DECISAO SOBRE AGRESSAO ALUNOS EM ESCOLA',1,1),(19,291,34,'2014-01-08','10:14:44','PARCERIA PAE SENAC',1,1);
/*!40000 ALTER TABLE `protocolo_pro` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-07-02 17:13:37
