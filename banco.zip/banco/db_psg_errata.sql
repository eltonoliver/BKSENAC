CREATE DATABASE  IF NOT EXISTS `db_psg` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `db_psg`;
-- MySQL dump 10.13  Distrib 5.6.17, for Win32 (x86)
--
-- Host: 127.0.0.1    Database: db_psg
-- ------------------------------------------------------
-- Server version	5.6.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `errata`
--

DROP TABLE IF EXISTS `errata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `errata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nomeErrata` varchar(145) NOT NULL,
  `arquivoErrata` varchar(145) NOT NULL,
  `data` date DEFAULT NULL,
  `edital_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`,`edital_id`),
  KEY `fk_errata_edital_idx` (`edital_id`),
  CONSTRAINT `fk_errata_edital` FOREIGN KEY (`edital_id`) REFERENCES `edital` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `errata`
--

LOCK TABLES `errata` WRITE;
/*!40000 ALTER TABLE `errata` DISABLE KEYS */;
INSERT INTO `errata` VALUES (1,'Errata 01 - edital 09.2014 LR','a6a19-errata-01-edital-09.2014-lr.pdf',NULL,14),(2,'Errata 02 - edital 09.2014 LR','ee5cd-errata-02-edital-09.2014-lr.pdf',NULL,14),(5,'Errata 1 - edital 12.2014 CIN','f2d28-errata-1---edital-12.2014-cin.pdf',NULL,20),(6,'Errata 1 - edital 17.2014 PJP','c900a-errata-1-edital-17.2014-pjp.pdf',NULL,26),(9,'Errata 01- edital 31.2014','53d27-errata-001---edital-31.2014-pjp.pdf',NULL,45),(10,'Errata 01 - edital 34.2014 MPR','e00a2-errata-01-.-edital-34.2014-mpr.pdf',NULL,55),(11,'Errata 001 - edital 37.2014 LR','14e88-errata-001---edital-37.2014-lr.pdf',NULL,53),(12,'Errata 001','9ed92-errata-001---edital-38.2014-cth.pdf',NULL,54),(13,'Errata 001 - edital 39.2014 PJP','8e3a4-errata-001---edital-39.2014-pjp.pdf',NULL,59),(14,'Errata 002 - edital 37.2014 LR','a4f32-errata-002---edital-37.2014-lr.pdf',NULL,53),(15,'Errata 001 - edital 42.2014 CIN','4754e-errata-001--edital-42.2014-cin.pdf',NULL,63),(16,'Errata 001','21107-errata-001---edital-33.2014-mpr.pdf',NULL,57),(20,'Errata 002 - edital 42.2014 CIN','27912-errata-002--edital-42.2014-cin.pdf',NULL,63),(21,'Errata 001 - edital 43.2014 CIN','1d798-errata-001---edital-43.2014-cin.pdf',NULL,66),(22,'Errata 002 - edital 43.2014 CIN','dbacb-errata-002---edital-43.2014-cin.pdf',NULL,66),(23,'Errata 001','973c3-errata-001---edital-46.2014-cth.pdf',NULL,69),(25,'Errata 003','6dbc3-errata-003---edital-43.2014-cin.pdf',NULL,66);
/*!40000 ALTER TABLE `errata` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-07-02 17:13:51
