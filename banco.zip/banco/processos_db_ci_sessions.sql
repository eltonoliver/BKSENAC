CREATE DATABASE  IF NOT EXISTS `processos_db` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `processos_db`;
-- MySQL dump 10.13  Distrib 5.6.17, for Win32 (x86)
--
-- Host: 127.0.0.1    Database: processos_db
-- ------------------------------------------------------
-- Server version	5.6.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ci_sessions`
--

DROP TABLE IF EXISTS `ci_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ci_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(45) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ci_sessions`
--

LOCK TABLES `ci_sessions` WRITE;
/*!40000 ALTER TABLE `ci_sessions` DISABLE KEYS */;
INSERT INTO `ci_sessions` VALUES ('020875e1ac438f85de254c88a89ec5e0','179.222.83.245','Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.137 Safari/537.36',1400686517,''),('03359cffceec7366257230527360d0ef','179.234.194.213','Mozilla/5.0 (Windows NT 6.2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.137 Safari/537.36',1400688665,''),('12527e953770e9f8b3a28641f341e11d','180.76.6.60','Mozilla/5.0 (compatible; Baiduspider/2.0; +http://www.baidu.com/search/spider.html)',1400685574,'a:2:{s:9:\"user_data\";s:0:\"\";s:10:\"idProcesso\";s:2:\"18\";}'),('13b32134cb07654dce4d801dccfc6c97','201.75.66.88','Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.137 Safari/537.36',1400690119,''),('186f958f08f57e32ee9f7cb768f99d21','187.24.72.7','Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.137 Safari/537.36',1400683682,''),('2a09b74b2911e09256ebbbaaff93251f','179.214.161.223','Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; Win64; x64; Trident/5.0; .NET CLR 2.0.50727; SLCC2; .NET CLR 3.5.3072',1400684153,''),('3a1c31a2058f68c1368c85274fba2e2f','200.160.99.95','Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.114 Safari/537.36',1400683569,''),('4ea8d9de6e35e58d8a87058e97ff8e8f','200.165.161.106','Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0)',1400690495,''),('4f4a2e6fb5c65cf073e4e206c659addc','179.222.54.164','Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.137 Safari/537.36',1400687893,''),('4f98758fd3804d0331dcda23c62b41a9','189.80.121.11','Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.137 Safari/537.36',1400687878,''),('5361ce9faec4924a2af661ee098df1a4','179.234.195.184','Mozilla/5.0 (Windows NT 6.1; rv:29.0) Gecko/20100101 Firefox/29.0',1400682086,''),('59bb0676105b562e66ed6a2e99b66394','200.208.54.250','Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.137 Safari/537.36',1400682156,''),('7598ad9e8ec2601ecda0bbcdd1c35f6f','177.5.216.221','Mozilla/5.0 (Windows NT 6.1; rv:29.0) Gecko/20100101 Firefox/29.0',1400685923,''),('831d6c1c7aade4dc1a327c73ec69295d','161.162.84.84','Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.66 Safari/537.36',1400690991,''),('8c2d03acf776dd4641db2513a1679f6d','177.180.8.139','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.114 Safari/537.36',1400690089,''),('8ec1b65ae6db4758f23c0c46f8f0105c','177.180.31.161','Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.137 Safari/537.36',1400689385,''),('9147a6e826c1edc1293191eded46eda1','177.180.6.138','Mozilla/5.0 (X11; Linux i686 on x86_64; rv:18.0) Gecko/20100101 Firefox/18.0',1400682889,''),('97211a4a4a45b0bc3791531b81f89f18','201.9.96.89','Mozilla/5.0 (Windows NT 6.1; Trident/7.0; rv:11.0) like Gecko',1400682304,''),('98bdb08dc66c50251479825473fd0c1f','200.242.114.148','Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; Trident/6.0)',1400681224,''),('9b6b37094b9b7b83f9c4b679850b4934','179.222.0.130','Mozilla/5.0 (iPad; CPU OS 7_1_1 like Mac OS X) AppleWebKit/537.51.2 (KHTML, like Gecko) Version/7.0 Mobile/11D201 Safari',1400686163,''),('9ed44506d39c204dcfea93cac78484ef','191.8.246.186','Mozilla/5.0 (Windows NT 6.1; rv:29.0) Gecko/20100101 Firefox/29.0',1400687927,''),('a668bd3cff0ccd34d86a671f002c33d6','200.160.96.66','Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; BTRS100205; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; ',1400685858,''),('a741b9a237adfb33131b1c31369e6971','201.75.67.240','Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.137 Safari/537.36',1400681942,''),('c03e7c4ee0bec47121d86b0dfd3f8cee','187.2.147.112','Mozilla/5.0 (Windows NT 6.1; rv:29.0) Gecko/20100101 Firefox/29.0',1400684240,''),('c2603238f0930cd4975dcdaa685031d4','200.208.54.229','0',1400685337,''),('c3344e4bf2864598ccd8036ff4c11857','200.208.54.229','0',1400685294,''),('c34a596c0044e0a324f2dbb34ee84d1a','201.90.101.178','Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.137 Safari/537.36',1400688911,''),('e0d25bf8cc5977aba63a989b700ef098','177.179.18.71','Mozilla/5.0 (Windows NT 6.3; WOW64; Trident/7.0; rv:11.0) like Gecko',1400688315,''),('e52fa25dbcd96e679216a692037e52d8','201.75.46.179','Mozilla/5.0 (iPhone; CPU iPhone OS 7_1_1 like Mac OS X) AppleWebKit/537.51.2 (KHTML, like Gecko) Version/7.0 Mobile/11D2',1400690337,''),('e6f8f75019426c64703fe271df582cf6','201.51.82.15','Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.131 Safari/537.36',1400688880,''),('e7993bb6e064b7603c678d07deac202b','200.208.54.250','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:29.0) Gecko/20100101 Firefox/29.0',1400685170,'a:1:{s:10:\"idProcesso\";s:2:\"31\";}'),('ee19b4a703604f1dc8c08ff7c792afcc','177.180.6.208','Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.137 Safari/537.36',1400689254,''),('f97994aa6990094dc40be64a3a750f0d','187.90.108.138','Mozilla/5.0 (iPhone; CPU iPhone OS 7_1_1 like Mac OS X) AppleWebKit/537.51.2 (KHTML, like Gecko) Version/7.0 Mobile/11D2',1400687205,''),('faedc8f604d21f8559d4e21686f5e1a2','191.160.92.9','Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.137 Safari/537.36',1400687050,'');
/*!40000 ALTER TABLE `ci_sessions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-07-02 17:13:33
