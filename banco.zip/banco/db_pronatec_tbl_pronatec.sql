CREATE DATABASE  IF NOT EXISTS `db_pronatec` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `db_pronatec`;
-- MySQL dump 10.13  Distrib 5.6.17, for Win32 (x86)
--
-- Host: 127.0.0.1    Database: db_pronatec
-- ------------------------------------------------------
-- Server version	5.6.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbl_pronatec`
--

DROP TABLE IF EXISTS `tbl_pronatec`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_pronatec` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` varchar(200) NOT NULL,
  `idUser` int(11) DEFAULT NULL,
  `arquivo` varchar(145) NOT NULL,
  `data` date DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_pronatec`
--

LOCK TABLES `tbl_pronatec` WRITE;
/*!40000 ALTER TABLE `tbl_pronatec` DISABLE KEYS */;
INSERT INTO `tbl_pronatec` VALUES (1,' Cancelamento de Matrículas - 2014',59,'db314-cancelamento-de-pre-matricula-e-matriculas-confirmadas.pdf','2014-03-18',1),(2,'Edital Sisutec - 03/2014 Alunos Publicados',59,'83451-edital-sisutec-2014-1---alunos-publicado-(1).pdf','2014-03-18',1),(3,'Status de Matrículas - SISTEC',59,'c5135-sistec-status-de-matriculas---04.11.2013.pdf','2014-03-18',1),(4,'Decreto PRONATEC -  Lei 12.513 Outubro 2011',59,'37d07-lei-no-12.513_26-de-outubro-de-2011.pdf','2014-03-18',1),(5,'Técnicos Subsequentes Aprovados ',59,'7be0f-quadro----proposta-cursos-tecnicos-subsequentes-2014.pdf','2014-03-19',1),(6,'Guia FIC 3ª  Edição 11/2013',59,'29de9-guia-pronatec-de-cursos-fic-3a.-edicao---portaria-mec-899-2013.pdf','2014-03-19',1),(7,'Código de Recurso por Demandante',59,'3c994-codigo-de-recurso---demandantes-pronatec.jpg','2014-04-09',1),(8,'Portaria 114/2014 - SISUTEC',59,'be695-portaria--114---pronatec---7-02-2014--(oficial).pdf','2014-04-24',1);
/*!40000 ALTER TABLE `tbl_pronatec` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-07-02 17:13:53
