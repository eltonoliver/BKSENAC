CREATE DATABASE  IF NOT EXISTS `processos_db` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `processos_db`;
-- MySQL dump 10.13  Distrib 5.6.17, for Win32 (x86)
--
-- Host: 127.0.0.1    Database: processos_db
-- ------------------------------------------------------
-- Server version	5.6.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `anexos`
--

DROP TABLE IF EXISTS `anexos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `anexos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `anexo` varchar(145) NOT NULL,
  `processo_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`processo_id`),
  KEY `fk_Anexos_processo1_idx` (`processo_id`),
  CONSTRAINT `fk_Anexos_processo1` FOREIGN KEY (`processo_id`) REFERENCES `processo` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `anexos`
--

LOCK TABLES `anexos` WRITE;
/*!40000 ALTER TABLE `anexos` DISABLE KEYS */;
INSERT INTO `anexos` VALUES (40,'b3d75-anexo-i---edital-no-002.pdf',5),(41,'860be-anexo-ii---edital-no-002.pdf',5),(43,'cabe2-anexo-ii---edital-no-011.pdf',16),(44,'e96d8-anexo-i---edital-no-011.pdf',16),(45,'f0c77-anexo-i---edital-no-012.pdf',17),(46,'a47aa-anexo-ii---edital-no-012.pdf',17),(47,'5fdbb-anexo-i---edital-no-013.pdf',18),(49,'6f1fb-anexo-ii---edital-no-013.pdf',18),(52,'6f21b-anexo-ii---edital-no-014.pdf',19),(53,'180fc-anexo_i---edital_no003.pdf',6),(54,'f035a-anexo_ii---edital_no003.pdf',6),(55,'97130-anexo-i---edital-no-014.pdf',19),(56,'48ba3-anexo_i---edital_no-004.pdf',7),(57,'731f0-anexo_ii---edital_no-004.pdf',7),(58,'1f0c4-anexo_i---edital_no-005.pdf',20),(59,'c315d-anexo_ii---edital_no-005.pdf',20),(60,'918a2-anexo_i---edital_no-006.pdf',21),(61,'51f22-anexo_ii---edital_no-006.pdf',21),(62,'3e6b2-anexo_i---edital_no-007.pdf',22),(63,'26c40-anexo_ii---edital_no-007.pdf',22),(64,'e9515-anexo_i---edital_no-008.pdf',23),(65,'95534-anexo_ii---edital_no-008.pdf',23),(66,'b0385-anexo_i---edital_no-009.pdf',24),(67,'97c87-anexo_ii---edital_no-009.pdf',24),(68,'49a67-anexo_i---edital_no-010.pdf',25),(69,'bbbca-anexo_ii---edital_no-010.pdf',25),(70,'45208-anexo-i---edital-no-015.pdf',26),(71,'2e457-anexo-ii---edital-no-015.pdf',26),(72,'1b2a9-anexo_i---edital_no-016.pdf',27),(73,'ce6cf-anexo_ii---edital_no-016.pdf',27),(74,'2e684-anexo-i---edital-no-017.pdf',28),(75,'a8702-anexo-ii---edital-no-017.pdf',28),(76,'1b777-anexo-i---edital-no-14.pdf',29),(77,'d6843-anexo-ii---edital-no-14.pdf',29),(78,'45653-anexo-i---edital-no-018.pdf',30),(79,'8261a-anexo-ii---edital-no-018.pdf',30),(80,'7e698-anexo-i---edital-no-001.pdf',4),(81,'ce85c-anexo-ii---edital-no-001.pdf',4),(84,'7426f-anexo-i---edital-no-019.pdf',31),(85,'ecc0f-anexo-ii---edital-no-019_2014.pdf',31);
/*!40000 ALTER TABLE `anexos` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-07-02 17:13:34
