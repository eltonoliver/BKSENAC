CREATE DATABASE  IF NOT EXISTS `db_base` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `db_base`;
-- MySQL dump 10.13  Distrib 5.6.17, for Win32 (x86)
--
-- Host: 127.0.0.1    Database: db_base
-- ------------------------------------------------------
-- Server version	5.6.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `emailusuario_emus`
--

DROP TABLE IF EXISTS `emailusuario_emus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `emailusuario_emus` (
  `emus_codusuario` int(10) unsigned NOT NULL,
  `emus_email` varchar(60) NOT NULL,
  PRIMARY KEY (`emus_codusuario`,`emus_email`),
  KEY `fk_emus_codusuario` (`emus_codusuario`),
  CONSTRAINT `fk_emus_codusuario` FOREIGN KEY (`emus_codusuario`) REFERENCES `usuario_usu` (`usu_codusuario`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `emailusuario_emus`
--

LOCK TABLES `emailusuario_emus` WRITE;
/*!40000 ALTER TABLE `emailusuario_emus` DISABLE KEYS */;
INSERT INTO `emailusuario_emus` VALUES (2,'victor.augusto@am.senac.br'),(3,'adriana.santos@am.senac.br'),(4,'leila.azevedo@am.senac.br'),(5,'lia.mara@am.senac.br'),(6,'adailton.freitas@am.senac.br'),(7,'lucas.ribeiro@am.senac.br'),(8,'alba.saldanha@am.senac.br'),(9,'alessandra.moraes@am.senac.br'),(10,'alessandra.barreto@am.senac.br'),(11,'lucineide.castilho@am.senac.br'),(12,'alex.marques@am.senac.br'),(13,'ricardo.almeida@am.senac.br'),(14,'luiza.marillac@am.senac.br'),(15,'aline.reis@am.senac.br'),(16,'luizete.moreira@am.senac.br'),(17,'allesandra.castro@am.senac.br'),(18,'luzilene.sena@am.senac.br'),(20,'marcilene.carvalho@am.senac.br'),(21,'maria.inez@am.senac.br'),(22,'angela.lima@am.senac.br'),(23,'maria.cida@am.senac.br'),(24,'maria.lourdes@am.senac.br'),(25,'maria.auxiadora@am.senac.br'),(26,'maria.barbosa@am.senac.br'),(27,'auzilene.souza@am.senac.br'),(28,'marilia.santos@am.senac.br'),(29,'marilia.melo@am.senac.br'),(30,'bosco.cantisani@am.senac.br'),(31,'mirna.lemos@am.senac.br'),(32,'bruno.layme@am.senac.br'),(33,'nailson.andrade@am.senac.br'),(34,'neilon.batista@am.senac.br'),(35,'pedro.brandao@am.senac.br'),(36,'carlos.taveira@am.senac.br'),(37,'queila.souza@am.senac.br'),(38,'railma.benevides@am.senac.br'),(39,'renata.silva@am.senac.br'),(40,'rizete.trovao@am.senac.br'),(41,'carmen.honorato@am.senac.br'),(42,'roberval.nunes@am.senac.br'),(43,'robson.gadelha@am.senac.br'),(44,'cecilia.xavier@am.senac.br'),(45,'roosevelt.alves@am.senac.br'),(46,'ciria.coelho@am.senac.br'),(47,'rosedilson.santos@am.senac.br'),(48,'saiana.lopes@am.senac.br'),(49,'claudia.suely@am.senac.br'),(50,'samia.alcantara@am.senac.br'),(52,'cristina.pinho@am.senac.br'),(53,'sheila.almeida@am.senac.br'),(54,'silmar.nunes@am.senac.br'),(56,'silvana.carvalho@am.senac.br'),(57,'simey.ramos@am.senac.br'),(58,'socorro.pereira@am.senac.br'),(59,'suammy.rocha@am.senac.br'),(60,'suellen.vinente@am.senac.br'),(61,'sueudes.furtado@am.senac.br'),(62,'danielle_gsilva@am.senac.br'),(63,'tania.melo@am.senac.br'),(64,'doriciana.caldas@am.senac.br'),(65,'vera.lucia@am.senac.br'),(66,'viviane.buzaglo@am.senac.br'),(67,'wanderly.salgado@am.senac.br'),(68,'wilza.claudia@am.senac.br'),(69,'wilzania.nascimento@am.senac.br'),(70,'duciane.froes@am.senac.br'),(71,'ederson.pinto@am.senac.br'),(72,'ediane.lavor@am.senac.br'),(73,'edson.dantas@am.senac.br'),(74,'eleni.meneses@am.senac.br'),(75,'eliana.carvalho@am.senac.br'),(76,'elizangela.balbi@am.senac.br'),(77,'enedina.batista@am.senac.br'),(78,'erika.sampaio@am.senac.br'),(79,'fatima.dabela@am.senac.br'),(80,'francisca.silvestre@am.senac.br'),(81,'francisco.gama@am.senac.br'),(82,'francisco.claudio@am.senac.br'),(83,'frank.melo@am.senac.br'),(84,'geralda.correa@am.senac.br'),(85,'guilherme.galindo@am.senac.br'),(86,'haroldo.wilson@am.senac.br'),(87,'helenizes.pereira@am.senac.br'),(88,'janete.almeida@am.senac.br'),(89,'jilcelin.souza@am.senac.br'),(90,'joane.tomaz@am.senac.br'),(91,'jucicley.abecassis@am.senac.br'),(92,' juracema.carvalho@am.senac.br'),(93,'katia.costa@am.sen'),(94,'laercio.filho@am.senac.br'),(95,'senira.batalha@am.senac.br'),(96,'nelverton.silva@am.senac.br'),(97,'songe.adegas@am.senac.br'),(98,'tatiana.malosso@am.senac.br'),(99,'rayonilia.silva@am.senac.br'),(100,'rozineide.amorim@am.senac.br'),(102,'alexandre.braganca@am.senac.br'),(103,'gessineide.teofilo@am.senac.br'),(104,'denise.xavier@am.senac.br'),(105,'larissa.almeida@am.senac.br'),(106,'giza.pedroso@am.senac.br'),(107,'carlos.souza@am.senac.br'),(108,'silvia.vieira@am.senac.br'),(109,'gianne.teixeira@am.senac.br'),(110,'jociana.belem@am.senac.br'),(111,'paula.santos@am.senac.br'),(112,'daniele.lima@am.senac.br'),(113,'jeise.santos@am.senac.br'),(114,'raimunda.nonata@am.senac.br'),(115,'junymar.farias@am.senac.br'),(116,'jamilson.santos@am.senac.br'),(117,'nubia.figueira@am.senac.br'),(118,'analu.oliveira@am.senac.br'),(119,'giselle.souza@am.senac.br'),(120,'ivan.lima@am.senac.br'),(121,'cinthia.silva@am.senac.br'),(123,'elaine.lima@am.senac.br'),(124,'jocemilda.viana@am.senac.br'),(125,'heleonora.pinto@am.senac.br'),(126,'wullanson.oliveira@am.senac.br'),(127,'jumara.silva@am.senac.br'),(128,'carswell.lima@am.senac.br'),(129,'fernando.mauricio@am.senac.br'),(130,'marfiza.alves@am.senac.br'),(131,'jessica.santos@am.senac.br'),(132,'raul.echenique@am.senac.br'),(133,'fernando.mauricio@am.senac.br'),(135,'karla.bessa@am.senac.br'),(136,'marlisson.silva@am.senac.br'),(137,'tania.santos@am.senac.br'),(139,'leliomar.picanco@am.senac.br'),(140,'mariselma.manfredo@am.senac.br'),(141,'genelene.silva@am.senac.br'),(142,'esmeralda.oliveira@am.senac.br'),(143,'ana.kyssia@am.senac.br'),(144,'ryckson.silva@am.senac.br'),(145,'edilene.nunes@am.senac.br'),(146,'saide.trindade@am.senac.br'),(147,'anderson.rosario@am.senac.br'),(148,'ellen.nestori@am.senac.br'),(149,'ricardo.rodrigues@am.senac.br'),(150,'jucicleide.silva@am.senac.br'),(151,'monara.brito@am.senac.br'),(152,'jander.peres@am.senac.br'),(153,'tatiana.frota@am.senac.br'),(154,'marilen.santos@am.senac.br'),(155,'mauro.augusto@am.senac.br'),(156,'suelen.kamily@am.senac.br'),(157,'elivaney.ribeiro@am.senac.br'),(158,'nerismar.lima@am.senac.br'),(159,'rafaela.lima@am.senac.br'),(160,'rosangela.lopes@am.senac.br'),(161,'erika.monteiro@am.senac.br'),(162,'alidiane.alves@am.senac.br'),(163,'elton.oliveira@am.senac.br'),(164,'amarildo.moreira@am.senac.br'),(165,'roberto.dias@am.senac.br'),(166,'kellen.cruz@am.senac.br'),(167,'camila.lima@am.senac.br'),(168,'danielle.moraes@am.senac.br'),(169,'elen.kelly@am.senac.br '),(170,'paulo.santangelo@am.senac.br'),(172,'luiz.pimentel@lion.am.senac.br'),(175,'israel.galvao@am.senac.br'),(176,'ana.nogueira@am.senac.br'),(177,'tania.rebello@am.senac.br'),(178,'catarina.silva@am.senac.br'),(179,'vanuza.matos@am.senac.br'),(180,'flavio.pereira@am.senac.br'),(181,'naiami.pavao@am.senac.br'),(185,'edilangela.freires@am.senac.br'),(186,'rui.alencar@am.senac.br'),(187,'orlenia.oliveira@am.senac.br'),(188,'sergio.bichara@am.senac.br'),(189,'olismar.nascimento@am.senac.br'),(190,'mirian.araqui@am.senac.br'),(191,'marcia.pontes@am.senac.br'),(197,'alidia.gomes@am.senac.br'),(198,'thayse.silva@am.senac.br'),(199,'paula.martins@am.senac,br'),(205,'mackson.silva@am.senac.br'),(207,'maria.edleusa@am.senac.br'),(210,'anne.leal@am.senac.br'),(212,'fernanda.souza@am.senac.br'),(213,'alessandra.lima@am.senac.br'),(214,'lilian.nunes@am.senac.br'),(216,'kezia.silva@am.senac.br'),(217,'laide.silva@am.senac.br'),(218,'alexandre.lopes@am.senac.br'),(219,'endrio.medeiros@am.senac.br'),(220,'ricardo.evencio@am.senac.br');
/*!40000 ALTER TABLE `emailusuario_emus` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-07-02 17:13:55
