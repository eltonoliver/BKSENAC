CREATE DATABASE  IF NOT EXISTS `db_base` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `db_base`;
-- MySQL dump 10.13  Distrib 5.6.17, for Win32 (x86)
--
-- Host: 127.0.0.1    Database: db_base
-- ------------------------------------------------------
-- Server version	5.6.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `fonedepartamento_fodep`
--

DROP TABLE IF EXISTS `fonedepartamento_fodep`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fonedepartamento_fodep` (
  `fodep_numero` varchar(14) NOT NULL,
  `fodep_coddepartamento` int(10) unsigned NOT NULL,
  `fodep_codtipo` int(10) unsigned NOT NULL,
  `fodep_codunidade` int(11) DEFAULT NULL,
  PRIMARY KEY (`fodep_numero`,`fodep_coddepartamento`),
  KEY `fk_fodep_coddepartamento` (`fodep_coddepartamento`),
  KEY `fk_fodep_codtipo` (`fodep_codtipo`),
  CONSTRAINT `fk_fodep_coddepartamento` FOREIGN KEY (`fodep_coddepartamento`) REFERENCES `departamento_dep` (`dep_coddepartamento`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_fodep_codtipo` FOREIGN KEY (`fodep_codtipo`) REFERENCES `tipotelefone_tipfo` (`tipfo_codtipo`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fonedepartamento_fodep`
--

LOCK TABLES `fonedepartamento_fodep` WRITE;
/*!40000 ALTER TABLE `fonedepartamento_fodep` DISABLE KEYS */;
INSERT INTO `fonedepartamento_fodep` VALUES ('9232157181',29,1,16),('9232157182',30,1,16),('9232157183',34,1,16),('9232157186',31,2,16),('9232157188',3,1,2),('9232157190',2,1,2),('9232165032',19,1,12),('9232165033',18,1,12),('9232165040',20,1,12),('9232165060',21,1,12),('9232165744',5,1,3),('9232165745',6,1,3),('9232165746',7,1,4),('9232165747',7,2,4),('9232165750',14,1,10),('9232165751',14,1,10),('9232165754',17,1,12),('9232165755',13,1,9),('9232165755',46,1,21),('9232165758',1,1,1),('9232165761',13,1,9),('9232165762',22,1,13),('9232165763',15,1,11),('9232165764',22,1,13),('9232165767',11,1,8),('9232165769',10,1,7),('9232165770',12,1,8),('9232165771',9,1,6),('9232165772',9,2,6),('9232165773',8,1,5),('9232165774',44,1,20),('9232165775',16,2,12),('9232165779',25,1,14),('9232165780',23,1,14),('9232165782',27,1,14),('9232165785',24,2,14),('9232165787',26,1,14),('9232166190',37,1,17),('9232166191',38,1,17),('9232167162',36,1,17),('9232167181',45,1,21),('9232167184',32,1,16),('9232167565',39,1,17),('9233611785',28,2,15),('9235211500',43,2,19),('9235212131',43,1,19),('9235333129',42,2,18),('9235333134',41,2,18),('9236351132',33,1,16),('9236377823',4,1,2),('9236412002',40,1,17);
/*!40000 ALTER TABLE `fonedepartamento_fodep` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-07-02 17:13:54
