CREATE DATABASE  IF NOT EXISTS `db_siaf` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `db_siaf`;
-- MySQL dump 10.13  Distrib 5.6.17, for Win32 (x86)
--
-- Host: 127.0.0.1    Database: db_siaf
-- ------------------------------------------------------
-- Server version	5.6.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tipoconta_tipco`
--

DROP TABLE IF EXISTS `tipoconta_tipco`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipoconta_tipco` (
  `tipco_codtipco` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tipco_tipoconta` varchar(80) NOT NULL,
  `tipco_codtipo` int(10) unsigned NOT NULL,
  `tipco_codusuario` int(10) unsigned NOT NULL,
  `tipco_codunidade` int(10) unsigned NOT NULL,
  PRIMARY KEY (`tipco_codtipco`),
  KEY `fk_tipco_codtipo` (`tipco_codtipo`),
  KEY `fk_tipco_codusuario` (`tipco_codusuario`),
  KEY `fk_tipco_codunidade` (`tipco_codunidade`),
  CONSTRAINT `fk_tipco_codtipo` FOREIGN KEY (`tipco_codtipo`) REFERENCES `tipomovimento_tipmo` (`tipmo_codtipo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_tipco_codunidade` FOREIGN KEY (`tipco_codunidade`) REFERENCES `unidade_uni` (`uni_codunidade`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_tipco_codusuario` FOREIGN KEY (`tipco_codusuario`) REFERENCES `usuario_usu` (`usu_codusuario`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipoconta_tipco`
--

LOCK TABLES `tipoconta_tipco` WRITE;
/*!40000 ALTER TABLE `tipoconta_tipco` DISABLE KEYS */;
INSERT INTO `tipoconta_tipco` VALUES (1,'RECEITA DN',1,2,1),(2,'RECEITA DR',1,2,1),(3,'DESPESAS CORRENTES',2,2,1),(4,'DESPESAS DE CAPITAL',2,2,1),(5,'RECEITA DN',1,6,2),(6,'RECEITA DR',1,6,2),(7,'DESPESA CORRENTES',2,4,2),(8,'DESPESA DE CAPITAL',2,6,2);
/*!40000 ALTER TABLE `tipoconta_tipco` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-07-02 17:13:47
