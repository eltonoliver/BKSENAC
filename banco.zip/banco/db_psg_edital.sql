CREATE DATABASE  IF NOT EXISTS `db_psg` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `db_psg`;
-- MySQL dump 10.13  Distrib 5.6.17, for Win32 (x86)
--
-- Host: 127.0.0.1    Database: db_psg
-- ------------------------------------------------------
-- Server version	5.6.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `edital`
--

DROP TABLE IF EXISTS `edital`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edital` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nomeEdital` varchar(85) NOT NULL,
  `arquivoEdital` varchar(145) NOT NULL,
  `data` date NOT NULL,
  `estado_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`estado_id`,`status_id`),
  KEY `fk_edital_estado1_idx` (`estado_id`),
  KEY `fk_edital_status1_idx` (`status_id`),
  CONSTRAINT `fk_edital_status1` FOREIGN KEY (`status_id`) REFERENCES `status` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edital`
--

LOCK TABLES `edital` WRITE;
/*!40000 ALTER TABLE `edital` DISABLE KEYS */;
INSERT INTO `edital` VALUES (14,'Edital 09.2014 LR','b0422-edital-09.2014-lr.pdf','2014-01-10',3,2),(20,'Edital 12.2014 CIN','76525-edital-12.2014-cin---tec.-manutencao.pdf','2014-01-16',3,2),(22,'Edital 01.2014 LR','71ce4-psg-01.2014.-lr.pdf','2014-01-02',3,2),(23,'Edital 15.2014 - CIN','d22b8-edital-15.2014-pro-menor---cin.pdf','2014-01-24',3,2),(26,'Edital 17.2014 PJP','3ecf9-edital-17.2014-pjp.pdf','2014-01-29',3,2),(28,'Edital 19.2014 CTH - Téc. Cozinha','61241-edital-19.2014-cth-tec.-cozinha.pdf','2014-01-31',3,2),(30,'Edital 21.2014 CIN','eeaef-edital-21.2014-cin.pdf','2014-02-04',3,2),(34,'Edital 25.2014 Carreta Escola - CIN','d91a1-edital-25.2014-carreta-escola---cin.pdf','2014-02-12',3,2),(39,'Edital 30.2014 MBI','2cab9-edital-30.2014-mbi.pdf','2014-03-11',3,2),(41,'Edital 24.2014 PF','3d88c-edital-24.2014-pf.pdf','2014-02-24',3,2),(44,'Edital 29.2014 LB','6504a-edital-29.2014--lb.pdf','2014-03-06',3,2),(45,'Edital 31.2014 PJP','52e34-edital-31.2014-pjp.pdf','2014-03-14',3,2),(53,'Edital 37.2014 LR','adeed-edital-37.2014-lr.pdf','2014-03-27',3,2),(54,'Edital 38.2014 CTH','063a0-edital-38.2014-cth.doc','2014-03-27',3,2),(55,'Edital 34.2014 MPR','19757-edital-34.2014-mpr.pdf','2014-03-25',3,2),(56,'Edital 32.2014 PF','75433-edital-32.2014-pf.pdf','2014-03-18',3,2),(57,'Edital 33.2014 MPR','32965-edital-33.2014-mpr.pdf','2014-03-19',3,2),(58,'Edital 35.2014 CTH','e9592-edital-35.2014-cth.pdf','2014-03-25',3,2),(59,'Edital 39.2014 PJP','6f681-edital-39.2014-pjp.pdf','2014-03-27',3,2),(60,'Edital 40.2014 LB','99679-edital-40.2014-lb.pdf','2014-03-31',3,2),(61,'Edital 41.2014 PF','8c307-edital-41.2014-pf.pdf','2014-03-31',3,2),(62,'Edital 36.2014 PJP','93523-edital-36.2014-pjp.pdf','2014-03-26',3,2),(63,'Edital 42.2014 CIN','21402-edital-42.2014-cin.pdf','2014-04-02',3,2),(64,'Edital 20.2014 CTH','aedcc-edital-20.2014-cth.pdf','2014-02-14',3,2),(65,'Edital 23.2014 MPR','8051b-edital-23.2014-mpr.pdf','2014-02-13',3,2),(66,'Edital 43.2014 CIN','15bd1-edital-43.2014-cin---pro-menor-dom-bosco.pdf','2014-04-04',2,1),(67,'Edital 44.2014 JT','18a67-edital-44.2014-jt.pdf','2014-04-08',3,2),(68,'Edital 45.2014 PF','7821d-edital-45.2014-pf-tec-adm.pdf','2014-04-09',3,2),(69,'Edital 46.2014 CTH','e2d6c-edital-46.2014-cth.pdf','2014-04-04',3,2),(70,'Edital 51.2014 CTH','b811b-edital-tec-cozinhaa.pdf','2014-04-07',3,2),(72,'Edital 47.2014 CTH','51f3b-edital-47.2014-cth-aperf-garcom.pdf','2014-04-15',3,2),(74,'Edital 50.2014 CTH','9f8dc-edital-50.2014-cth-piloto.pdf','2014-04-23',3,2),(75,'Edital 55.2014 CTH','95c8f-edital-55.2014-cth.pdf','2014-05-02',3,2),(85,'Edital 62.2014 PF','4fee0-edital-62.2014-pf.doc','2014-05-05',3,1),(86,'Edital 69.2014 CTH','5f685-edital-69.2014-cth-salgadeiro.pdf','2014-05-20',1,1),(87,'Edital 59.2014 PJP','5a730-edital-59.2014-pjp.doc','2014-05-05',3,1),(88,'Edital 63.2014 LB','6251b-lista-de-classificados--tecnico-63.pdf','2014-05-06',3,1),(89,'Edital 56.2014 LB','aa744-edital-56.2014-lb.pdf','2014-05-02',3,2),(90,'Edital 49.2014 MPR','cb4a2-edital-49.2014-mpr.pdf','2014-04-23',2,1),(91,'Edital 52.2014 PJP','9dee8-edital-52.2014-pjp-bombeiro-civil.pdf','2014-04-25',2,1),(92,'Edital 54.2014 MPR','50fe6-edital-54.2014-mpr.pdf','2014-04-30',2,1),(93,'Edital 57.2014 LR','6bc70-edital-57.2014-lr.pdf','2014-05-02',2,1),(94,'Edital 58.2014 MPR','86754-edital-58.2014-mpr.doc','2014-05-05',2,1),(95,'Edital 61.2014 CTH','17c24-edital-61.2014-cth.doc','2014-05-05',3,1),(96,'Edital 64.2014 JT','a48d3-edital-64.2014-jt.pdf','2014-05-08',3,1),(97,'Edital 65.2014 LB','e6e0b-edital-65.2014-lb.pdf','2014-05-08',3,1),(98,'Edital 66.2014 CIN','6b5c9-edital-66.2014-cin-tecnicos.pdf','2014-05-08',3,1),(99,'Edital 67.2014 LB','9923c-edital-67.2014-lb.pdf','2014-05-14',2,1),(100,'Edital 68.2014 LB','17d35-edital-68.2014-lb.pdf','2014-05-15',2,1);
/*!40000 ALTER TABLE `edital` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-07-02 17:13:51
