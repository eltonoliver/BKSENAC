CREATE DATABASE  IF NOT EXISTS `db_base` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `db_base`;
-- MySQL dump 10.13  Distrib 5.6.17, for Win32 (x86)
--
-- Host: 127.0.0.1    Database: db_base
-- ------------------------------------------------------
-- Server version	5.6.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `unidade_uni`
--

DROP TABLE IF EXISTS `unidade_uni`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `unidade_uni` (
  `uni_codunidade` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uni_nomecompleto` varchar(150) NOT NULL,
  `uni_nomeabreviado` varchar(60) NOT NULL,
  `uni_cnpj` varchar(45) DEFAULT NULL,
  `uni_cep` varchar(15) DEFAULT NULL,
  `uni_logradouro` varchar(90) DEFAULT NULL,
  `uni_bairro` varchar(80) DEFAULT NULL,
  `uni_cidade` varchar(70) DEFAULT NULL,
  `uni_estado` varchar(30) DEFAULT NULL,
  `uni_coddisp` int(10) unsigned NOT NULL,
  `uni_codtipo` int(10) unsigned NOT NULL,
  `uni_codsituacao` int(10) unsigned NOT NULL,
  `uni_codtipres` int(10) unsigned NOT NULL,
  `uni_permitirmodeloa` int(11) NOT NULL DEFAULT '2',
  PRIMARY KEY (`uni_codunidade`),
  KEY `fk_uni_coddisp` (`uni_coddisp`),
  KEY `fk_uni_codtipo` (`uni_codtipo`),
  KEY `fk_uni_codsituacao` (`uni_codsituacao`),
  KEY `fk_uni_codtipres` (`uni_codtipres`),
  CONSTRAINT `fk_uni_coddisp` FOREIGN KEY (`uni_coddisp`) REFERENCES `disponibilizarsite_disp` (`disp_coddisp`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_uni_codsituacao` FOREIGN KEY (`uni_codsituacao`) REFERENCES `situacaosistema_sitsis` (`sitsis_codsituacao`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_uni_codtipo` FOREIGN KEY (`uni_codtipo`) REFERENCES `tipounidade_tiun` (`tiun_codtipo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_uni_codtipres` FOREIGN KEY (`uni_codtipres`) REFERENCES `tiporesponsavel_tire` (`tire_codtipo`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `unidade_uni`
--

LOCK TABLES `unidade_uni` WRITE;
/*!40000 ALTER TABLE `unidade_uni` DISABLE KEYS */;
INSERT INTO `unidade_uni` VALUES (1,'GERÊNCIA DE INFORMÁTICA CORPORATIVA','SEDE ADMINISTRATIVA - GIC','03965450000107','69050010','Av. Darcy Vargas 2705','Chapada','Manaus','Am',2,1,1,1,1),(2,'CENTRO DE TURISMO E HOSPITALIDADE','CENTRO DE TURISMO E HOSPITALIDADE','03965450000107','69040010','Rua Saldanha Marinho 644','Centro','Manaus','Am',2,1,1,1,2),(3,'DIRETORIA REGIONAL','SEDE ADMINISTRATIVA - DRG','03965450000107','69050010','Av. Dajalma Batista 2507','Chapada','Manaus','Am',2,1,1,1,2),(4,'GABINETE EXECUTIVO','SEDE ADMINISTRATIVA - GEX','03965450000107','69050010','Av. Djalma Batista 2507','Chapada','Manaus','Am',2,1,1,1,2),(5,'GERÊNCIA DE CONTABILIDADE','SEDE ADMINISTRATIVA - GCO','03965450000107','69050010','Av. Djalma Batista 2507','Chapada','Manaus','Am',2,1,1,1,2),(6,'GERÊNCIA DE MATERIAIS','SEDE ADMINISTRATIVA - GMA','03965450000107','69050010','Av. Djalma Batista 2507','Chapada','Manaus','Am',2,1,1,1,2),(7,'GERÊNCIA DE RECURSOS HUMANOS','SEDE ADMINISTRATIVA - GRH','03965450000107','69050010','Av. Djalma Batista 2507','Chapada','Manaus','Am',2,1,1,1,2),(8,'DIVISÃO ADMINISTRATIVA','SEDE ADMINISTRATIVA - DAD','03965450000107','69050010','Av. Djalma Batista 2507','Chapada','Manaus','Am',2,1,1,1,2),(9,'DIVISÃO DE PLANEJAMENTO E MARKETING','SEDE ADMINISTRATIVA - DPM','03965450000107','69050010','Av. Djalma Batista 2507','Chapada','Manaus','Am',2,1,1,2,2),(10,'GERÊNCIA DE PROJETOS ESPECIAIS','SEDE ADMINISTRATIVA - GPE','03965450000107','69050010','Av. Djalma Batista','Chapada','Manaus','Am',2,1,1,1,1),(11,'DIVISÃO DE EDUCAÇÃO PROFISSIONAL','SEDE ADMINISTRATIVA - DEP','03965450000107','69050010','Av. Dajalma Batista','Chapada','Manaus','Am',2,1,1,1,2),(12,'GERÊNCIA DE MANUTENÇÃO E TRANSPORTE','SEDE ADMINISTRATIVA - GMT','03965450000107','69050010','Av. Djalma Batista 2507','Chapada','Manaus','Am',2,1,1,1,2),(13,'GABINETE TÉCNICO - DEP','SEDE ADMINISTRATIVA - GTC/DEP','03965450000107','69050010','Av. Djalma Batista 2507','Chapada','Manaus','Am',2,1,1,1,2),(14,'CFP - MANOEL CATHARINO DOS SANTOS GOMES','CFP - MANOEL CATHARINO DOS SANTOS GOMES','03965450000298','69050020','Av. Darcy Vargas 288','Chapada','Manaus','Am',2,1,1,1,1),(15,'CFP - LÁZARO DA SILVA REIS','CFP - LÁZARO DA SILVA REIS','03965450000530','69400000','Rua Waldemar Ventura 612','São José','Manacapuru','Am',2,1,1,1,1),(16,'CFP - FERNANDO ALFREDO  PEQUENO FRANCO','CFP - FERNANDO ALFREDO  PEQUENO FRANCO','03965450000379','69040010','Rua Saldanha Marinho 644','Centro','Manaus','Am',2,1,1,1,1),(17,'CFP - JOSÉ TADROS','CFP - JOSÉ TADROS','03965450000450','69090340','Rua Visconde de Itanhaem  863','Cidade Nova','Manaus','Am',2,1,1,1,1),(18,'CFP - MATHEUS PENNA RIBEIRO','CFP - MATHEUS PENNA RIBEIRO','03965450000700','69151320','Av. Massaranduba S/N','Djard Vieira','Parintins','Am',2,1,1,1,1),(19,'CFP - MOYSÉS BENARRÓS ISRAEL','CFP - MOYSÉS BENARRÓS ISRRAEL','03965450000611','69100000','Rua Adamastor de Figueiredo 2207','Centro','Itacoatiara','Am',2,1,1,1,1),(20,'SETOR DE CAIXA','SEDE ADMINISTRATIVA - SCX','03965450000107','69050010','Av. Djalma Batista 2507','Chapada','Manaus','Am',2,1,1,1,2),(21,'GABINETE TÉCNICO - DPM','SEDE ADMINISTRATIVA - GTC/DPM','03965450000107','69050010','Av. Djalma Batista 2507','Chapada','Manaus','Am',2,1,1,1,2),(22,'CFP - LILI BENCHIMOL','CFP - LILI BENCHIMOL','','','','','','',1,1,1,1,1),(23,'DEP/SUPERVISAO/CRISTINA','DEP/SUPERVISAO/CRISTINA','','','','','','',2,1,1,1,2),(24,'EDUCAÇÃO CORPORATIVA','EDUCAÇÃO CORPORATIVA','','','','','','',2,1,1,1,2),(25,'CFP - PROFESSOR JEFFERSON PERES','CFP - PROFESSOR JEFFERSON PERES','','','','','Coari','AM',2,1,1,1,1),(26,'SEDOC','SEDOC','','','','','','',2,1,1,1,2),(27,'DIVISÃO FINANCEIRA','SEDE ADMINISTRATIVA - DIF','03965450000107','69050010','Avenida Djalma Batista','Chapada','Manaus','AM',2,1,1,1,2),(28,'SECRETARIA ACADÊMICA','SECRETARIA ACADÊMICA','','69050010','Avenida Djalma Batista','Chapada','Manaus','AM',2,1,1,1,2),(29,'CFP - BALSA ESCOLA','BALSA ESCOLA','','','','','','',2,1,1,1,1),(30,'FACULDADE DE TECNOLOGIA SENAC','FATESE','','','','','','',2,1,1,1,1),(31,'ASSESSORIA DE CONTROLE INTERNO','ASSESSORIA DE CONTROLE INTERNO','','','','','','',2,1,1,1,2),(32,'SEDE ADMINISTRATIVA - OBRAS','SEDE ADMINISTRATIVA - OBRAS','','','','','','',2,1,1,1,2),(33,'ENGENHARIA - OBRAS','ENGENHARIA - OBRAS','','','','','','',2,1,1,1,2),(34,'GESTÃO DE CONTRATOS','GESTÃO DE CONTRATOS','','','','','','',2,1,1,1,2),(35,'ASSESSORIA JURÍDICA','ASSESSORIA JURÍDICA','','','','','','',2,1,1,1,2),(36,'OLIMPIADAS DO CONHECIMENTO','OLIMPIADAS DO CONHECIMENTO','','','','','','',2,1,1,1,2),(37,'RESERVA TÉCNICA','RESERVA TÉCNICA','','','','','','',2,1,1,1,2),(38,'DESPESAS GERAIS','DESPESAS GERAIS','','','','','','',2,1,1,1,2),(39,'SERVIÇO DE PASSAGENS','SERVIÇO DE PASSAGENS','','','','','','',2,1,1,1,2),(40,'SECRETARIA DAD','SECRETARIA DAD','','','','','','',2,1,1,1,2),(41,'COMISSÃO DE LICITAÇÃO SENAC','COMISSÃO DE LICITAÇÃO SENAC','','','','','','',2,1,1,1,2),(42,'COMISSÃO DE LICITAÇÃO SESC / SENAC','COMISSÃO DE LICITAÇÃO SESC / SENAC','','','','','','',2,1,1,1,2),(43,'CIPA','CIPA','','','','','','',2,1,1,1,2);
/*!40000 ALTER TABLE `unidade_uni` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-07-02 17:13:57
